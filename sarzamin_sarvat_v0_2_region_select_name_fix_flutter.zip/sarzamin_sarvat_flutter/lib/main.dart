import 'dart:async';
import 'dart:math' as math;

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:shared_preferences/shared_preferences.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await SystemChrome.setPreferredOrientations(const <DeviceOrientation>[
    DeviceOrientation.landscapeLeft,
    DeviceOrientation.landscapeRight,
  ]);
  await SystemChrome.setEnabledSystemUIMode(SystemUiMode.immersiveSticky);
  runApp(const SarzaminSarvatApp());
}

class SarzaminSarvatApp extends StatelessWidget {
  const SarzaminSarvatApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'سرزمین ثروت',
      theme: ThemeData(
        useMaterial3: true,
        brightness: Brightness.dark,
        scaffoldBackgroundColor: const Color(0xFF1B1208),
        fontFamily: 'sans',
      ),
      builder: (context, child) {
        return Directionality(
          textDirection: TextDirection.rtl,
          child: child ?? const SizedBox.shrink(),
        );
      },
      home: const SplashScreen(),
    );
  }
}

enum RegionId { north, south, west, east }

class RegionData {
  const RegionData({
    required this.id,
    required this.title,
    required this.shortTitle,
    required this.description,
    required this.resources,
    required this.opportunity,
    required this.challenge,
    required this.style,
    required this.color,
    required this.secondaryColor,
  });

  final RegionId id;
  final String title;
  final String shortTitle;
  final String description;
  final List<String> resources;
  final String opportunity;
  final String challenge;
  final String style;
  final Color color;
  final Color secondaryColor;
}

const List<RegionData> kRegions = <RegionData>[
  RegionData(
    id: RegionId.north,
    title: 'منطقه شمال و شمال‌مرکز',
    shortTitle: 'شمال',
    description: 'تهران، البرز، قزوین، گیلان، مازندران و گلستان. بازار مصرف قوی، غذا و چوب بیشتر، معدن کمتر و هزینه ساخت بالاتر.',
    resources: <String>['چوب', 'غذا', 'محصول کشاورزی', 'بازار فروش'],
    opportunity: 'فروش محصولات مصرفی، تجارت شهری و کشاورزی سریع‌تر.',
    challenge: 'معدن ضعیف‌تر، زمین گران‌تر و رقابت بیشتر.',
    style: 'کشاورزی، چوب، بازار مصرف و رشد تجاری آرام.',
    color: Color(0xFF57B26A),
    secondaryColor: Color(0xFF2D6B4B),
  ),
  RegionData(
    id: RegionId.south,
    title: 'منطقه جنوب',
    shortTitle: 'جنوب',
    description: 'سیستان و بلوچستان، هرمزگان، بوشهر، خوزستان و جنوب کرمان. خشک‌تر، اما مناسب معدن، مصالح و مسیرهای بندری.',
    resources: <String>['سنگ', 'آهن', 'مصالح', 'تجارت دریایی'],
    opportunity: 'استخراج معدن، فروش مصالح، کالاهای بندری و تجارت سنگین.',
    challenge: 'چوب و کشاورزی محدودتر و نیاز بیشتر به مدیریت غذا.',
    style: 'معدن، بندر، مصالح و تجارت دوربرد.',
    color: Color(0xFFD89636),
    secondaryColor: Color(0xFF8B5A28),
  ),
  RegionData(
    id: RegionId.west,
    title: 'منطقه غرب',
    shortTitle: 'غرب',
    description: 'کردستان، کرمانشاه، ایلام، لرستان، همدان و آذربایجان غربی. کوهستانی، مناسب دامداری، سنگ و چوب متوسط.',
    resources: <String>['دامداری', 'پوست', 'سنگ', 'چوب متوسط'],
    opportunity: 'تولید محصولات دامی، سنگ، کارگاه‌های سنتی و تجارت منطقه‌ای.',
    challenge: 'بازار فروش کوچک‌تر و مسیرهای تجاری کندتر از مرکز.',
    style: 'دامداری، سنگ، کارگاه و رشد پایدار.',
    color: Color(0xFF8C9A4C),
    secondaryColor: Color(0xFF4D5B2C),
  ),
  RegionData(
    id: RegionId.east,
    title: 'منطقه شرق',
    shortTitle: 'شرق',
    description: 'خراسان‌ها، یزد، کرمان و نواحی شرقی. مناسب زعفران، کالاهای خاص، معادن و مسیرهای کاروانی.',
    resources: <String>['زعفران', 'معدن', 'کالاهای خاص', 'کاروان'],
    opportunity: 'تجارت کاروانی، کالاهای ارزشمند کم‌حجم و بازار خاص.',
    challenge: 'آب و چوب کمتر و وابستگی بیشتر به مسیرهای تجارت.',
    style: 'زعفران، کاروان، معدن و تجارت تخصصی.',
    color: Color(0xFFB678D8),
    secondaryColor: Color(0xFF6F3B8D),
  ),
];

RegionData regionById(RegionId id) => kRegions.firstWhere((item) => item.id == id);

RegionData regionByName(String? name) {
  for (final region in kRegions) {
    if (region.id.name == name) return region;
  }
  return kRegions.first;
}

class GameStorage {
  static const String _guestIdKey = 'guest_id';
  static const String _regionKey = 'selected_region';
  static const String _playerNameKey = 'player_name';
  static const String _coinsKey = 'coins';
  static const String _woodKey = 'wood';
  static const String _stoneKey = 'stone';
  static const String _ironKey = 'iron';
  static const String _foodKey = 'food';

  static Future<String> ensureGuest() async {
    final prefs = await SharedPreferences.getInstance();
    final saved = prefs.getString(_guestIdKey);
    if (saved != null && saved.isNotEmpty) return saved;
    final random = math.Random().nextInt(999999);
    final id = 'guest_${DateTime.now().millisecondsSinceEpoch}_$random';
    await prefs.setString(_guestIdKey, id);
    await prefs.setInt(_coinsKey, 120);
    await prefs.setInt(_woodKey, 8);
    await prefs.setInt(_stoneKey, 5);
    await prefs.setInt(_ironKey, 2);
    await prefs.setInt(_foodKey, 12);
    return id;
  }

  static Future<void> saveRegion(RegionId id) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(_regionKey, id.name);
  }

  static Future<RegionData?> loadRegion() async {
    final prefs = await SharedPreferences.getInstance();
    final name = prefs.getString(_regionKey);
    if (name == null) return null;
    return regionByName(name);
  }

  static Future<String?> loadPlayerName() async {
    final prefs = await SharedPreferences.getInstance();
    final value = prefs.getString(_playerNameKey)?.trim();
    if (value == null || value.isEmpty) return null;
    return value;
  }

  static Future<void> savePlayerName(String name) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(_playerNameKey, name.trim());
  }

  static Future<Map<String, int>> loadResources() async {
    final prefs = await SharedPreferences.getInstance();
    return <String, int>{
      'coin': prefs.getInt(_coinsKey) ?? 120,
      'wood': prefs.getInt(_woodKey) ?? 8,
      'stone': prefs.getInt(_stoneKey) ?? 5,
      'iron': prefs.getInt(_ironKey) ?? 2,
      'food': prefs.getInt(_foodKey) ?? 12,
    };
  }

  static Future<void> saveResources(Map<String, int> resources) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setInt(_coinsKey, resources['coin'] ?? 0);
    await prefs.setInt(_woodKey, resources['wood'] ?? 0);
    await prefs.setInt(_stoneKey, resources['stone'] ?? 0);
    await prefs.setInt(_ironKey, resources['iron'] ?? 0);
    await prefs.setInt(_foodKey, resources['food'] ?? 0);
  }
}

class SplashScreen extends StatefulWidget {
  const SplashScreen({super.key});

  @override
  State<SplashScreen> createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen> with SingleTickerProviderStateMixin {
  late final AnimationController _controller;

  @override
  void initState() {
    super.initState();
    SystemChrome.setEnabledSystemUIMode(SystemUiMode.immersiveSticky);
    _controller = AnimationController(vsync: this, duration: const Duration(milliseconds: 2500));
    _prepare();
  }

  Future<void> _prepare() async {
    await GameStorage.ensureGuest();
    if (!mounted) return;
    unawaited(_controller.forward());
    await Future<void>.delayed(const Duration(milliseconds: 2700));
    if (!mounted) return;
    final savedRegion = await GameStorage.loadRegion();
    if (!mounted) return;
    await Navigator.of(context).pushReplacement(
      PageRouteBuilder(
        transitionDuration: const Duration(milliseconds: 650),
        pageBuilder: (_, animation, __) => FadeTransition(opacity: animation, child: StartMapScreen(savedRegion: savedRegion)),
      ),
    );
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Stack(
        fit: StackFit.expand,
        children: <Widget>[
          CustomPaint(painter: SplashPainter()),
          Container(
            decoration: const BoxDecoration(
              gradient: LinearGradient(
                begin: Alignment.topCenter,
                end: Alignment.bottomCenter,
                colors: <Color>[Color(0x66000000), Color(0x11000000), Color(0xAA1B1208)],
              ),
            ),
          ),
          Center(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: <Widget>[
                Text(
                  'سرزمین ثروت',
                  style: TextStyle(
                    fontSize: 54,
                    fontWeight: FontWeight.w900,
                    color: const Color(0xFFFFE1A1),
                    shadows: <Shadow>[Shadow(color: Colors.black.withOpacity(0.8), blurRadius: 18, offset: const Offset(0, 5))],
                  ),
                ),
                const SizedBox(height: 10),
                Text('تجارت کن، منابع بساز، ثروتت را گسترش بده', style: TextStyle(color: Colors.white.withOpacity(0.86), fontSize: 18, fontWeight: FontWeight.w600)),
              ],
            ),
          ),
          Align(
            alignment: Alignment.bottomCenter,
            child: Padding(
              padding: const EdgeInsets.only(bottom: 34, left: 230, right: 230),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: <Widget>[
                  ClipRRect(
                    borderRadius: BorderRadius.circular(20),
                    child: AnimatedBuilder(
                      animation: _controller,
                      builder: (context, _) {
                        return LinearProgressIndicator(
                          value: _controller.value,
                          minHeight: 11,
                          backgroundColor: const Color(0xFF4A341C),
                          valueColor: const AlwaysStoppedAnimation<Color>(Color(0xFFFFC95C)),
                        );
                      },
                    ),
                  ),
                  const SizedBox(height: 10),
                  Text('آماده‌سازی نقشه و اقتصاد بازی...', style: TextStyle(color: Colors.white.withOpacity(0.72))),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class StartMapScreen extends StatefulWidget {
  const StartMapScreen({super.key, this.savedRegion});

  final RegionData? savedRegion;

  @override
  State<StartMapScreen> createState() => _StartMapScreenState();
}

class _StartMapScreenState extends State<StartMapScreen> {
  RegionData? _selected;
  bool _showReveal = false;
  bool _starting = false;

  @override
  void initState() {
    super.initState();
    SystemChrome.setEnabledSystemUIMode(SystemUiMode.immersiveSticky);
    _selected = widget.savedRegion;
  }

  Future<void> _openSettings() async {
    await showDialog<void>(context: context, builder: (_) => const SettingsDialog());
    await SystemChrome.setEnabledSystemUIMode(SystemUiMode.immersiveSticky);
  }

  Future<void> _showRegionInfo(RegionData data) async {
    await showDialog<void>(context: context, builder: (_) => RegionInfoDialog(data: data));
    await SystemChrome.setEnabledSystemUIMode(SystemUiMode.immersiveSticky);
  }

  Future<void> _startRegion(RegionData region) async {
    if (_starting) return;
    setState(() {
      _starting = true;
      _selected = region;
    });
    await GameStorage.saveRegion(region.id);
    if (!mounted) return;
    setState(() => _showReveal = true);
  }

  void _finishReveal() {
    unawaited(_goAfterReveal());
  }

  Future<void> _goAfterReveal() async {
    if (!mounted) return;
    final region = _selected ?? kRegions.first;
    final name = await GameStorage.loadPlayerName();
    if (!mounted) return;
    final next = (name == null || name.isEmpty) ? NameSetupScreen(region: region) : PlayerLandScreen(region: region, playerName: name);
    await Navigator.of(context).pushReplacement(
      PageRouteBuilder(
        transitionDuration: const Duration(milliseconds: 500),
        pageBuilder: (_, animation, __) => FadeTransition(opacity: animation, child: next),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final selected = _selected;
    return Scaffold(
      body: Stack(
        fit: StackFit.expand,
        children: <Widget>[
          CustomPaint(painter: ParchmentBackgroundPainter()),
          SafeArea(
            child: Padding(
              padding: const EdgeInsets.fromLTRB(14, 10, 14, 10),
              child: Row(
                textDirection: TextDirection.ltr,
                children: <Widget>[
                  Expanded(
                    flex: 66,
                    child: _MapBoard(
                      selected: selected,
                      onSelect: (region) => setState(() => _selected = region),
                      onInfo: _showRegionInfo,
                    ),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    flex: 34,
                    child: _GuidePanel(
                      selected: selected,
                      hasSavedRegion: widget.savedRegion != null,
                      isBusy: _starting,
                      onSettings: _openSettings,
                      onStart: selected == null ? null : () => _startRegion(selected),
                    ),
                  ),
                ],
              ),
            ),
          ),
          if (_showReveal) RevealOverlay(region: _selected ?? kRegions.first, onFinished: _finishReveal),
        ],
      ),
    );
  }
}

class _MapBoard extends StatelessWidget {
  const _MapBoard({required this.selected, required this.onSelect, required this.onInfo});

  final RegionData? selected;
  final ValueChanged<RegionData> onSelect;
  final ValueChanged<RegionData> onInfo;

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(26),
        border: Border.all(color: const Color(0xFFE4B663), width: 2),
        boxShadow: <BoxShadow>[BoxShadow(color: Colors.black.withOpacity(0.35), blurRadius: 22, offset: const Offset(0, 12))],
      ),
      clipBehavior: Clip.antiAlias,
      child: Stack(
        fit: StackFit.expand,
        children: <Widget>[
          CustomPaint(painter: IranMapPainter(selected: selected)),
          Positioned(
            right: 18,
            top: 16,
            left: 78,
            child: _CompactTitleBanner(title: 'انتخاب سرزمین شروع', subtitle: 'منابع متفاوت؛ شانس پیشرفت برابر.'),
          ),
          _RegionMarker(
            region: regionById(RegionId.north),
            alignment: const Alignment(0.02, -0.62),
            infoAlignment: const Alignment(-0.36, -0.42),
            selected: selected?.id == RegionId.north,
            onSelect: onSelect,
            onInfo: onInfo,
          ),
          _RegionMarker(
            region: regionById(RegionId.south),
            alignment: const Alignment(0.02, 0.61),
            infoAlignment: const Alignment(0.38, 0.44),
            selected: selected?.id == RegionId.south,
            onSelect: onSelect,
            onInfo: onInfo,
          ),
          _RegionMarker(
            region: regionById(RegionId.west),
            alignment: const Alignment(-0.64, 0.02),
            infoAlignment: const Alignment(-0.41, 0.25),
            selected: selected?.id == RegionId.west,
            onSelect: onSelect,
            onInfo: onInfo,
          ),
          _RegionMarker(
            region: regionById(RegionId.east),
            alignment: const Alignment(0.66, 0.02),
            infoAlignment: const Alignment(0.40, -0.24),
            selected: selected?.id == RegionId.east,
            onSelect: onSelect,
            onInfo: onInfo,
          ),
          const Center(
            child: IgnorePointer(child: Text('+', style: TextStyle(fontSize: 56, fontWeight: FontWeight.w900, color: Color(0xAAFFE2A1)))),
          ),
          const Positioned(
            left: 18,
            bottom: 18,
            child: Opacity(opacity: 0.35, child: Icon(Icons.explore_rounded, size: 92, color: Color(0xFFFFE1A1))),
          ),
        ],
      ),
    );
  }
}

class _CompactTitleBanner extends StatelessWidget {
  const _CompactTitleBanner({required this.title, required this.subtitle});

  final String title;
  final String subtitle;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(20),
        color: const Color(0xCC2C1908),
        border: Border.all(color: const Color(0x88E4B663)),
      ),
      child: Row(
        children: <Widget>[
          const Icon(Icons.map_rounded, color: Color(0xFFFFD17A), size: 24),
          const SizedBox(width: 10),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisSize: MainAxisSize.min,
              children: <Widget>[
                Text(title, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(color: Color(0xFFFFE1A1), fontWeight: FontWeight.w900, fontSize: 18)),
                const SizedBox(height: 2),
                Text(subtitle, maxLines: 1, overflow: TextOverflow.ellipsis, style: TextStyle(color: Colors.white.withOpacity(0.76), fontSize: 11.5)),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _RegionMarker extends StatelessWidget {
  const _RegionMarker({required this.region, required this.alignment, required this.infoAlignment, required this.selected, required this.onSelect, required this.onInfo});

  final RegionData region;
  final Alignment alignment;
  final Alignment infoAlignment;
  final bool selected;
  final ValueChanged<RegionData> onSelect;
  final ValueChanged<RegionData> onInfo;

  @override
  Widget build(BuildContext context) {
    return Stack(
      children: <Widget>[
        Align(
          alignment: alignment,
          child: GestureDetector(
            onTap: () => onSelect(region),
            child: AnimatedContainer(
              duration: const Duration(milliseconds: 220),
              padding: EdgeInsets.symmetric(horizontal: selected ? 18 : 14, vertical: selected ? 10 : 8),
              decoration: BoxDecoration(
                color: selected ? region.color.withOpacity(0.75) : const Color(0xAA2A1808),
                borderRadius: BorderRadius.circular(22),
                border: Border.all(color: selected ? const Color(0xFFFFE1A1) : region.color.withOpacity(0.85), width: selected ? 2.2 : 1.3),
                boxShadow: <BoxShadow>[BoxShadow(color: selected ? region.color.withOpacity(0.45) : Colors.black.withOpacity(0.25), blurRadius: selected ? 16 : 8)],
              ),
              child: Text(region.shortTitle, style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w900, fontSize: 17)),
            ),
          ),
        ),
        Align(
          alignment: infoAlignment,
          child: InkWell(
            onTap: () => onInfo(region),
            borderRadius: BorderRadius.circular(26),
            child: Container(
              width: 34,
              height: 34,
              decoration: BoxDecoration(
                color: const Color(0xFFE5B560),
                shape: BoxShape.circle,
                border: Border.all(color: const Color(0xFFFFE3A4), width: 2),
                boxShadow: <BoxShadow>[BoxShadow(color: Colors.black.withOpacity(0.35), blurRadius: 8)],
              ),
              child: const Icon(Icons.question_mark_rounded, color: Color(0xFF34200C), size: 21),
            ),
          ),
        ),
      ],
    );
  }
}

class _GuidePanel extends StatelessWidget {
  const _GuidePanel({required this.selected, required this.hasSavedRegion, required this.isBusy, required this.onStart, required this.onSettings});

  final RegionData? selected;
  final bool hasSavedRegion;
  final bool isBusy;
  final VoidCallback? onStart;
  final VoidCallback onSettings;

  @override
  Widget build(BuildContext context) {
    final region = selected;
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(26),
        color: const Color(0xD31F160D),
        border: Border.all(color: const Color(0xFFE4B663), width: 1.5),
        boxShadow: <BoxShadow>[BoxShadow(color: Colors.black.withOpacity(0.35), blurRadius: 18, offset: const Offset(0, 10))],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: <Widget>[
          Row(
            children: <Widget>[
              _RoundIconButton(icon: Icons.settings_rounded, tooltip: 'تنظیمات', onTap: onSettings),
              const SizedBox(width: 10),
              const Expanded(child: Text('شروع بازی', maxLines: 1, overflow: TextOverflow.ellipsis, style: TextStyle(color: Color(0xFFFFE1A1), fontSize: 20, fontWeight: FontWeight.w900))),
            ],
          ),
          const SizedBox(height: 10),
          SizedBox(
            height: 92,
            child: Row(
              children: <Widget>[
                Container(
                  width: 82,
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(18),
                    gradient: const LinearGradient(colors: <Color>[Color(0xFF4B3017), Color(0xFF271609)]),
                    border: Border.all(color: const Color(0x55FFD17A)),
                  ),
                  child: CustomPaint(
                    painter: GuideCharacterPainter(),
                    child: const Align(
                      alignment: Alignment.bottomCenter,
                      child: Padding(
                        padding: EdgeInsets.only(bottom: 6),
                        child: Text('راهنما', style: TextStyle(color: Color(0xFFFFD98A), fontSize: 10, fontWeight: FontWeight.w800)),
                      ),
                    ),
                  ),
                ),
                const SizedBox(width: 10),
                Expanded(
                  child: Text(
                    'روی هر منطقه بزن تا انتخاب شود. علامت سؤال، ویژگی‌های همان منطقه را نشان می‌دهد.',
                    maxLines: 4,
                    overflow: TextOverflow.ellipsis,
                    style: TextStyle(color: Colors.white.withOpacity(0.80), height: 1.35, fontSize: 12.5),
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(height: 10),
          Expanded(
            child: AnimatedSwitcher(
              duration: const Duration(milliseconds: 250),
              child: region == null
                  ? _SmallHintBox(text: hasSavedRegion ? 'منطقه قبلی ذخیره شده؛ می‌توانی ادامه بدهی یا منطقه تازه انتخاب کنی.' : 'یکی از چهار منطقه نقشه را انتخاب کن. تعادل بازی حفظ می‌شود؛ فقط نوع منابع فرق دارد.')
                  : _SelectedRegionCard(region: region),
            ),
          ),
          const SizedBox(height: 10),
          _PrimaryGameButton(label: isBusy ? 'در حال ورود...' : (region == null ? 'ابتدا منطقه را انتخاب کن' : 'شروع از ${region.shortTitle}'), icon: Icons.play_arrow_rounded, onTap: isBusy ? null : onStart),
        ],
      ),
    );
  }
}

class _SmallHintBox extends StatelessWidget {
  const _SmallHintBox({required this.text});
  final String text;

  @override
  Widget build(BuildContext context) {
    return Container(
      key: ValueKey<String>(text),
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(borderRadius: BorderRadius.circular(16), color: const Color(0xFF32220F), border: Border.all(color: const Color(0x775D4528))),
      child: Center(child: Text(text, textAlign: TextAlign.center, style: TextStyle(color: Colors.white.withOpacity(0.78), fontSize: 13, height: 1.45))),
    );
  }
}

class _SelectedRegionCard extends StatelessWidget {
  const _SelectedRegionCard({required this.region});
  final RegionData region;

  @override
  Widget build(BuildContext context) {
    return Container(
      key: ValueKey<RegionId>(region.id),
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(16),
        gradient: LinearGradient(colors: <Color>[region.secondaryColor.withOpacity(0.85), const Color(0xFF24170B)]),
        border: Border.all(color: region.color.withOpacity(0.8)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          Text(region.title, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(color: Colors.white, fontSize: 15, fontWeight: FontWeight.w900)),
          const SizedBox(height: 6),
          Text(region.description, maxLines: 2, overflow: TextOverflow.ellipsis, style: TextStyle(color: Colors.white.withOpacity(0.78), height: 1.35, fontSize: 11.5)),
          const SizedBox(height: 8),
          Wrap(spacing: 6, runSpacing: 6, children: region.resources.take(3).map((item) => _ResourceTag(text: item)).toList()),
        ],
      ),
    );
  }
}

class RegionInfoDialog extends StatelessWidget {
  const RegionInfoDialog({super.key, required this.data});
  final RegionData data;

  @override
  Widget build(BuildContext context) {
    return Dialog(
      backgroundColor: Colors.transparent,
      child: Container(
        width: 620,
        padding: const EdgeInsets.all(20),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(28),
          gradient: const LinearGradient(begin: Alignment.topRight, end: Alignment.bottomLeft, colors: <Color>[Color(0xFF4B3017), Color(0xFF201207)]),
          border: Border.all(color: const Color(0xFFE8BD6F), width: 2),
          boxShadow: <BoxShadow>[BoxShadow(color: Colors.black.withOpacity(0.55), blurRadius: 26, offset: const Offset(0, 14))],
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: <Widget>[
            Row(
              children: <Widget>[
                CircleAvatar(backgroundColor: data.color, child: const Icon(Icons.public_rounded, color: Colors.white)),
                const SizedBox(width: 12),
                Expanded(child: Text(data.title, style: const TextStyle(fontSize: 23, fontWeight: FontWeight.w900, color: Color(0xFFFFE1A1)))),
                IconButton(onPressed: () => Navigator.of(context).pop(), icon: const Icon(Icons.close_rounded, color: Colors.white)),
              ],
            ),
            const SizedBox(height: 12),
            Text(data.description, style: TextStyle(color: Colors.white.withOpacity(0.86), fontSize: 14.5, height: 1.7)),
            const SizedBox(height: 14),
            _InfoSection(title: 'منابع قوی', text: data.resources.join('، '), icon: Icons.inventory_2_rounded),
            _InfoSection(title: 'فرصت اقتصادی', text: data.opportunity, icon: Icons.trending_up_rounded),
            _InfoSection(title: 'چالش', text: data.challenge, icon: Icons.warning_amber_rounded),
            _InfoSection(title: 'سبک پیشرفت', text: data.style, icon: Icons.route_rounded),
            const SizedBox(height: 12),
            _PrimaryGameButton(label: 'متوجه شدم', icon: Icons.check_rounded, onTap: () => Navigator.of(context).pop()),
          ],
        ),
      ),
    );
  }
}

class _InfoSection extends StatelessWidget {
  const _InfoSection({required this.title, required this.text, required this.icon});
  final String title;
  final String text;
  final IconData icon;

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.only(bottom: 8),
      padding: const EdgeInsets.all(10),
      decoration: BoxDecoration(color: Colors.black.withOpacity(0.19), borderRadius: BorderRadius.circular(16), border: Border.all(color: Colors.white.withOpacity(0.08))),
      child: Row(
        children: <Widget>[
          Icon(icon, color: const Color(0xFFFFD17A), size: 24),
          const SizedBox(width: 10),
          Expanded(
            child: RichText(
              text: TextSpan(
                style: const TextStyle(fontFamily: 'sans', color: Colors.white, height: 1.45),
                children: <TextSpan>[
                  TextSpan(text: '$title: ', style: const TextStyle(fontWeight: FontWeight.w900, color: Color(0xFFFFE1A1))),
                  TextSpan(text: text, style: TextStyle(color: Colors.white.withOpacity(0.82))),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class SettingsDialog extends StatelessWidget {
  const SettingsDialog({super.key});

  @override
  Widget build(BuildContext context) {
    return Dialog(
      backgroundColor: Colors.transparent,
      child: Container(
        width: 520,
        padding: const EdgeInsets.all(20),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(28),
          gradient: const LinearGradient(colors: <Color>[Color(0xFF4B3017), Color(0xFF1B1008)]),
          border: Border.all(color: const Color(0xFFE8BD6F), width: 2),
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: <Widget>[
            Row(
              children: <Widget>[
                const Icon(Icons.settings_rounded, color: Color(0xFFFFD17A)),
                const SizedBox(width: 10),
                const Expanded(child: Text('تنظیمات', style: TextStyle(color: Color(0xFFFFE1A1), fontSize: 23, fontWeight: FontWeight.w900))),
                IconButton(onPressed: () => Navigator.of(context).pop(), icon: const Icon(Icons.close_rounded, color: Colors.white)),
              ],
            ),
            const SizedBox(height: 12),
            Text('ورود و ثبت‌نام اجباری نیست. می‌توانی به‌صورت مهمان بازی کنی و بعداً همین پیشرفت را به حساب اصلی وصل کنی.', style: TextStyle(color: Colors.white.withOpacity(0.82), height: 1.6)),
            const SizedBox(height: 14),
            Row(
              children: <Widget>[
                Expanded(child: _MenuButton(label: 'ورود', icon: Icons.login_rounded, onTap: () {})),
                const SizedBox(width: 10),
                Expanded(child: _MenuButton(label: 'ثبت‌نام', icon: Icons.person_add_alt_1_rounded, onTap: () {})),
              ],
            ),
            const SizedBox(height: 10),
            _MenuButton(label: 'صدا و موسیقی', icon: Icons.volume_up_rounded, onTap: () {}),
            const SizedBox(height: 10),
            _MenuButton(label: 'پشتیبانی / قوانین', icon: Icons.support_agent_rounded, onTap: () {}),
          ],
        ),
      ),
    );
  }
}

class RevealOverlay extends StatefulWidget {
  const RevealOverlay({super.key, required this.region, required this.onFinished});
  final RegionData region;
  final VoidCallback onFinished;

  @override
  State<RevealOverlay> createState() => _RevealOverlayState();
}

class _RevealOverlayState extends State<RevealOverlay> with SingleTickerProviderStateMixin {
  late final AnimationController _controller;

  @override
  void initState() {
    super.initState();
    _controller = AnimationController(vsync: this, duration: const Duration(milliseconds: 1800));
    _controller.forward();
    _controller.addStatusListener((status) {
      if (status == AnimationStatus.completed) widget.onFinished();
    });
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: _controller,
      builder: (context, _) {
        final t = Curves.easeInOut.transform(_controller.value);
        final flash = (1 - (t - 0.35).abs() * 2).clamp(0.0, 1.0);
        return Stack(
          fit: StackFit.expand,
          children: <Widget>[
            Container(color: Colors.white.withOpacity(0.12 + flash * 0.72)),
            Transform.translate(offset: Offset(-MediaQuery.of(context).size.width * t, 0), child: CustomPaint(painter: CloudPainter(alignment: Alignment.centerLeft))),
            Transform.translate(offset: Offset(MediaQuery.of(context).size.width * t, 0), child: CustomPaint(painter: CloudPainter(alignment: Alignment.centerRight))),
            Center(
              child: Opacity(opacity: (1 - t).clamp(0.0, 1.0), child: Text('ورود به ${widget.region.shortTitle}', style: const TextStyle(color: Color(0xFF3B250C), fontSize: 30, fontWeight: FontWeight.w900))),
            ),
          ],
        );
      },
    );
  }
}

class NameSetupScreen extends StatefulWidget {
  const NameSetupScreen({super.key, required this.region});
  final RegionData region;

  @override
  State<NameSetupScreen> createState() => _NameSetupScreenState();
}

class _NameSetupScreenState extends State<NameSetupScreen> {
  final TextEditingController _controller = TextEditingController();
  String? _error;

  @override
  void initState() {
    super.initState();
    SystemChrome.setEnabledSystemUIMode(SystemUiMode.immersiveSticky);
    _loadName();
  }

  Future<void> _loadName() async {
    final saved = await GameStorage.loadPlayerName();
    if (!mounted) return;
    if (saved != null) _controller.text = saved;
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  Future<void> _continue() async {
    final name = _controller.text.trim();
    if (name.length < 3) {
      setState(() => _error = 'اسم باید حداقل ۳ کاراکتر باشد.');
      return;
    }
    if (name.length > 18) {
      setState(() => _error = 'اسم بهتر است بیشتر از ۱۸ کاراکتر نباشد.');
      return;
    }
    await GameStorage.savePlayerName(name);
    if (!mounted) return;
    await Navigator.of(context).pushReplacement(
      PageRouteBuilder(
        transitionDuration: const Duration(milliseconds: 520),
        pageBuilder: (_, animation, __) => FadeTransition(opacity: animation, child: PlayerLandScreen(region: widget.region, playerName: name)),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Stack(
        fit: StackFit.expand,
        children: <Widget>[
          CustomPaint(painter: RegionLandPainter(region: widget.region)),
          Container(color: Colors.black.withOpacity(0.42)),
          Center(
            child: ConstrainedBox(
              constraints: const BoxConstraints(maxWidth: 720),
              child: Container(
                padding: const EdgeInsets.all(22),
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(28),
                  gradient: const LinearGradient(colors: <Color>[Color(0xFF4B3017), Color(0xFF1B1008)]),
                  border: Border.all(color: const Color(0xFFE8BD6F), width: 2),
                  boxShadow: <BoxShadow>[BoxShadow(color: Colors.black.withOpacity(0.55), blurRadius: 26, offset: const Offset(0, 14))],
                ),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: <Widget>[
                    Row(
                      children: <Widget>[
                        CircleAvatar(backgroundColor: widget.region.color, child: const Icon(Icons.person_rounded, color: Colors.white)),
                        const SizedBox(width: 12),
                        const Expanded(child: Text('نام حساب مهمان را انتخاب کن', style: TextStyle(color: Color(0xFFFFE1A1), fontSize: 24, fontWeight: FontWeight.w900))),
                      ],
                    ),
                    const SizedBox(height: 10),
                    Text('این اسم برای همین حساب مهمان ذخیره می‌شود. بعداً اگر از تنظیمات ثبت‌نام کنی، همین پیشرفت به حساب اصلی وصل می‌شود.', style: TextStyle(color: Colors.white.withOpacity(0.82), height: 1.55, fontSize: 13.5)),
                    const SizedBox(height: 16),
                    TextField(
                      controller: _controller,
                      textInputAction: TextInputAction.done,
                      onSubmitted: (_) => _continue(),
                      maxLength: 18,
                      textAlign: TextAlign.center,
                      style: const TextStyle(color: Colors.white, fontSize: 20, fontWeight: FontWeight.w800),
                      decoration: InputDecoration(
                        counterText: '',
                        hintText: 'مثلاً: تاجر جوان',
                        hintStyle: TextStyle(color: Colors.white.withOpacity(0.38)),
                        errorText: _error,
                        filled: true,
                        fillColor: Colors.black.withOpacity(0.22),
                        enabledBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(18), borderSide: const BorderSide(color: Color(0x88E8BD6F))),
                        focusedBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(18), borderSide: const BorderSide(color: Color(0xFFFFD17A), width: 2)),
                        errorBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(18), borderSide: const BorderSide(color: Color(0xFFE86B58))),
                        focusedErrorBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(18), borderSide: const BorderSide(color: Color(0xFFE86B58), width: 2)),
                      ),
                    ),
                    const SizedBox(height: 14),
                    _PrimaryGameButton(label: 'ورود به منطقه ${widget.region.shortTitle}', icon: Icons.arrow_forward_rounded, onTap: _continue),
                  ],
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class PlayerLandScreen extends StatefulWidget {
  const PlayerLandScreen({super.key, required this.region, required this.playerName});
  final RegionData region;
  final String playerName;

  @override
  State<PlayerLandScreen> createState() => _PlayerLandScreenState();
}

class _PlayerLandScreenState extends State<PlayerLandScreen> {
  Map<String, int> _resources = <String, int>{'coin': 120, 'wood': 8, 'stone': 5, 'iron': 2, 'food': 12};

  @override
  void initState() {
    super.initState();
    SystemChrome.setEnabledSystemUIMode(SystemUiMode.immersiveSticky);
    _load();
  }

  Future<void> _load() async {
    final resources = await GameStorage.loadResources();
    if (mounted) setState(() => _resources = resources);
  }

  Future<void> _save() => GameStorage.saveResources(_resources);

  Future<void> _collectMainResource() async {
    final id = widget.region.id;
    setState(() {
      if (id == RegionId.north) {
        _resources['wood'] = (_resources['wood'] ?? 0) + 4;
        _resources['food'] = (_resources['food'] ?? 0) + 2;
      } else if (id == RegionId.south) {
        _resources['stone'] = (_resources['stone'] ?? 0) + 4;
        _resources['iron'] = (_resources['iron'] ?? 0) + 1;
      } else if (id == RegionId.west) {
        _resources['stone'] = (_resources['stone'] ?? 0) + 3;
        _resources['food'] = (_resources['food'] ?? 0) + 2;
      } else {
        _resources['iron'] = (_resources['iron'] ?? 0) + 2;
        _resources['food'] = (_resources['food'] ?? 0) + 1;
      }
    });
    await _save();
  }

  Future<void> _sellBundle() async {
    setState(() {
      final wood = _resources['wood'] ?? 0;
      final stone = _resources['stone'] ?? 0;
      final iron = _resources['iron'] ?? 0;
      final food = _resources['food'] ?? 0;
      if (wood + stone + iron + food <= 0) return;
      final sellWood = math.min(wood, 3);
      final sellStone = math.min(stone, 3);
      final sellIron = math.min(iron, 1);
      final sellFood = math.min(food, 2);
      _resources['wood'] = wood - sellWood;
      _resources['stone'] = stone - sellStone;
      _resources['iron'] = iron - sellIron;
      _resources['food'] = food - sellFood;
      _resources['coin'] = (_resources['coin'] ?? 0) + sellWood * 6 + sellStone * 5 + sellIron * 18 + sellFood * 4;
    });
    await _save();
  }

  Future<void> _openMarket() async {
    await showModalBottomSheet<void>(context: context, backgroundColor: Colors.transparent, builder: (_) => _MarketSheet(resources: _resources, onSell: _sellBundle));
    await SystemChrome.setEnabledSystemUIMode(SystemUiMode.immersiveSticky);
  }

  @override
  Widget build(BuildContext context) {
    final region = widget.region;
    return Scaffold(
      body: Stack(
        fit: StackFit.expand,
        children: <Widget>[
          CustomPaint(painter: RegionLandPainter(region: region)),
          SafeArea(
            child: Column(
              children: <Widget>[
                Padding(
                  padding: const EdgeInsets.fromLTRB(14, 10, 14, 0),
                  child: _ResourceBar(resources: _resources, region: region, playerName: widget.playerName),
                ),
                Expanded(
                  child: Row(
                    children: <Widget>[
                      Expanded(flex: 72, child: _LandInteractionLayer(region: region, onCollect: _collectMainResource, onMarket: _openMarket)),
                      Expanded(flex: 28, child: Padding(padding: const EdgeInsets.all(12), child: _MissionPanel(region: region, onCollect: _collectMainResource, onMarket: _openMarket))),
                    ],
                  ),
                ),
                Padding(padding: const EdgeInsets.fromLTRB(18, 0, 18, 12), child: _BottomGameMenu(onMarket: _openMarket)),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _ResourceBar extends StatelessWidget {
  const _ResourceBar({required this.resources, required this.region, required this.playerName});
  final Map<String, int> resources;
  final RegionData region;
  final String playerName;

  @override
  Widget build(BuildContext context) {
    return Container(
      height: 58,
      padding: const EdgeInsets.symmetric(horizontal: 12),
      decoration: BoxDecoration(borderRadius: BorderRadius.circular(20), color: const Color(0xDD20140A), border: Border.all(color: const Color(0xFFE4B663))),
      child: Row(
        children: <Widget>[
          Icon(Icons.shield_moon_rounded, color: region.color, size: 26),
          const SizedBox(width: 8),
          Text(playerName, style: const TextStyle(color: Color(0xFFFFE1A1), fontWeight: FontWeight.w900, fontSize: 15)),
          const SizedBox(width: 8),
          Text('منطقه ${region.shortTitle}', style: TextStyle(color: Colors.white.withOpacity(0.70), fontWeight: FontWeight.w700, fontSize: 12)),
          const Spacer(),
          _ResourcePill(icon: Icons.monetization_on_rounded, label: 'سکه', value: resources['coin'] ?? 0, color: const Color(0xFFFFD17A)),
          _ResourcePill(icon: Icons.forest_rounded, label: 'چوب', value: resources['wood'] ?? 0, color: const Color(0xFF7BC67B)),
          _ResourcePill(icon: Icons.terrain_rounded, label: 'سنگ', value: resources['stone'] ?? 0, color: const Color(0xFFC2B095)),
          _ResourcePill(icon: Icons.hardware_rounded, label: 'آهن', value: resources['iron'] ?? 0, color: const Color(0xFFBCC6CC)),
          _ResourcePill(icon: Icons.restaurant_rounded, label: 'غذا', value: resources['food'] ?? 0, color: const Color(0xFFFFB86B)),
        ],
      ),
    );
  }
}

class _ResourcePill extends StatelessWidget {
  const _ResourcePill({required this.icon, required this.label, required this.value, required this.color});
  final IconData icon;
  final String label;
  final int value;
  final Color color;

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.only(right: 8),
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 7),
      decoration: BoxDecoration(borderRadius: BorderRadius.circular(18), color: Colors.black.withOpacity(0.24), border: Border.all(color: color.withOpacity(0.55))),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: <Widget>[
          Icon(icon, color: color, size: 18),
          const SizedBox(width: 5),
          Text('$label $value', style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w800, fontSize: 12)),
        ],
      ),
    );
  }
}

class _LandInteractionLayer extends StatelessWidget {
  const _LandInteractionLayer({required this.region, required this.onCollect, required this.onMarket});
  final RegionData region;
  final VoidCallback onCollect;
  final VoidCallback onMarket;

  @override
  Widget build(BuildContext context) {
    return Stack(
      children: <Widget>[
        Align(alignment: const Alignment(-0.48, 0.02), child: _BuildingBubble(title: 'خانه', subtitle: 'سطح ۱', icon: Icons.home_work_rounded, color: const Color(0xFFBC8351), onTap: () {})),
        Align(alignment: const Alignment(0.02, 0.04), child: _BuildingBubble(title: 'بازار', subtitle: 'خرید و فروش', icon: Icons.storefront_rounded, color: const Color(0xFFE2A64E), onTap: onMarket)),
        Align(alignment: const Alignment(0.48, 0.0), child: _BuildingBubble(title: 'انبار', subtitle: 'منابع', icon: Icons.inventory_2_rounded, color: const Color(0xFF87935B), onTap: () {})),
        Align(alignment: const Alignment(-0.1, -0.48), child: _BuildingBubble(title: region.id == RegionId.south ? 'معدن' : region.id == RegionId.north ? 'جنگل' : region.id == RegionId.east ? 'کاروان' : 'کوهستان', subtitle: 'جمع‌آوری', icon: Icons.add_business_rounded, color: region.color, onTap: onCollect)),
        Align(alignment: const Alignment(0.0, 0.66), child: _PrimaryGameButton(label: 'جمع‌آوری منابع', icon: Icons.touch_app_rounded, onTap: onCollect)),
      ],
    );
  }
}

class _BuildingBubble extends StatelessWidget {
  const _BuildingBubble({required this.title, required this.subtitle, required this.icon, required this.color, required this.onTap});
  final String title;
  final String subtitle;
  final IconData icon;
  final Color color;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return InkWell(
      borderRadius: BorderRadius.circular(22),
      onTap: onTap,
      child: Container(
        width: 154,
        padding: const EdgeInsets.all(11),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(22),
          gradient: LinearGradient(colors: <Color>[color.withOpacity(0.92), const Color(0xFF2B1909)]),
          border: Border.all(color: const Color(0xFFFFD27C), width: 1.3),
          boxShadow: <BoxShadow>[BoxShadow(color: Colors.black.withOpacity(0.36), blurRadius: 14, offset: const Offset(0, 8))],
        ),
        child: Row(
          children: <Widget>[
            Icon(icon, color: Colors.white, size: 30),
            const SizedBox(width: 9),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisSize: MainAxisSize.min,
                children: <Widget>[
                  Text(title, style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w900, fontSize: 15)),
                  Text(subtitle, style: TextStyle(color: Colors.white.withOpacity(0.78), fontSize: 11)),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _MissionPanel extends StatelessWidget {
  const _MissionPanel({required this.region, required this.onCollect, required this.onMarket});
  final RegionData region;
  final VoidCallback onCollect;
  final VoidCallback onMarket;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(15),
      decoration: BoxDecoration(borderRadius: BorderRadius.circular(24), color: const Color(0xDD20140A), border: Border.all(color: const Color(0xFFE4B663))),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: <Widget>[
          const Text('آموزش شروع', style: TextStyle(color: Color(0xFFFFE1A1), fontWeight: FontWeight.w900, fontSize: 19)),
          const SizedBox(height: 8),
          Text('منطقه ${region.shortTitle} انتخاب شد. فعلاً منابع جمع کن و در بازار بفروش.', style: TextStyle(color: Colors.white.withOpacity(0.82), height: 1.55, fontSize: 13)),
          const SizedBox(height: 12),
          _StepText(number: 1, text: 'روی منبع اصلی منطقه بزن و آیتم جمع کن.'),
          _StepText(number: 2, text: 'وارد بازار شو و بخشی از منابع را بفروش.'),
          _StepText(number: 3, text: 'در نسخه بعد، کارگاه و تجارت آنلاین اضافه می‌شود.'),
          const Spacer(),
          _PrimaryGameButton(label: 'جمع‌آوری', icon: Icons.handyman_rounded, onTap: onCollect),
          const SizedBox(height: 8),
          _MenuButton(label: 'رفتن به بازار', icon: Icons.store_mall_directory_rounded, onTap: onMarket),
        ],
      ),
    );
  }
}

class _StepText extends StatelessWidget {
  const _StepText({required this.number, required this.text});
  final int number;
  final String text;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 8),
      child: Row(
        children: <Widget>[
          CircleAvatar(radius: 13, backgroundColor: const Color(0xFFE4B663), child: Text('$number', style: const TextStyle(color: Color(0xFF2A1808), fontWeight: FontWeight.w900, fontSize: 12))),
          const SizedBox(width: 8),
          Expanded(child: Text(text, style: TextStyle(color: Colors.white.withOpacity(0.82), height: 1.45, fontSize: 12.5))),
        ],
      ),
    );
  }
}

class _MarketSheet extends StatelessWidget {
  const _MarketSheet({required this.resources, required this.onSell});
  final Map<String, int> resources;
  final VoidCallback onSell;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.fromLTRB(18, 16, 18, 18),
      decoration: const BoxDecoration(color: Color(0xFF211408), borderRadius: BorderRadius.vertical(top: Radius.circular(28))),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: <Widget>[
          const Text('بازار منطقه', style: TextStyle(color: Color(0xFFFFE1A1), fontSize: 22, fontWeight: FontWeight.w900)),
          const SizedBox(height: 8),
          Text('بازار درآمد خودکار ندارد؛ فقط آیتم‌هایی را که جمع کرده‌ای می‌فروشی. قیمت‌ها در نسخه آنلاین از سرور می‌آیند.', style: TextStyle(color: Colors.white.withOpacity(0.78), height: 1.55)),
          const SizedBox(height: 12),
          Wrap(spacing: 8, runSpacing: 8, children: <Widget>[
            _ResourceTag(text: 'چوب: ${resources['wood'] ?? 0}'),
            _ResourceTag(text: 'سنگ: ${resources['stone'] ?? 0}'),
            _ResourceTag(text: 'آهن: ${resources['iron'] ?? 0}'),
            _ResourceTag(text: 'غذا: ${resources['food'] ?? 0}'),
          ]),
          const SizedBox(height: 16),
          _PrimaryGameButton(label: 'فروش بسته کوچک منابع', icon: Icons.sell_rounded, onTap: () { onSell(); Navigator.of(context).pop(); }),
        ],
      ),
    );
  }
}

class _BottomGameMenu extends StatelessWidget {
  const _BottomGameMenu({required this.onMarket});
  final VoidCallback onMarket;

  @override
  Widget build(BuildContext context) {
    return Container(
      height: 66,
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
      decoration: BoxDecoration(borderRadius: BorderRadius.circular(22), color: const Color(0xDD20140A), border: Border.all(color: const Color(0xFFE4B663))),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
        children: <Widget>[
          _BottomItem(icon: Icons.storefront_rounded, label: 'بازار', onTap: onMarket),
          _BottomItem(icon: Icons.inventory_rounded, label: 'انبار', onTap: () {}),
          _BottomItem(icon: Icons.construction_rounded, label: 'ساخت', onTap: () {}),
          _BottomItem(icon: Icons.map_rounded, label: 'نقشه', onTap: () {}),
          _BottomItem(icon: Icons.emoji_events_rounded, label: 'رتبه', onTap: () {}),
        ],
      ),
    );
  }
}

class _BottomItem extends StatelessWidget {
  const _BottomItem({required this.icon, required this.label, required this.onTap});
  final IconData icon;
  final String label;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return InkWell(
      borderRadius: BorderRadius.circular(14),
      onTap: onTap,
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 4),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: <Widget>[
            Icon(icon, color: const Color(0xFFFFD17A), size: 23),
            const SizedBox(height: 2),
            Text(label, style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w800, fontSize: 11)),
          ],
        ),
      ),
    );
  }
}

class _PrimaryGameButton extends StatelessWidget {
  const _PrimaryGameButton({required this.label, required this.icon, this.onTap});
  final String label;
  final IconData icon;
  final VoidCallback? onTap;

  @override
  Widget build(BuildContext context) {
    final enabled = onTap != null;
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(20),
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 180),
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 13),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(20),
          gradient: LinearGradient(colors: enabled ? const <Color>[Color(0xFFE0A94E), Color(0xFF8B551B)] : const <Color>[Color(0xFF5C5141), Color(0xFF332A20)]),
          border: Border.all(color: enabled ? const Color(0xFFFFE1A1) : const Color(0xFF766C5D), width: 1.3),
          boxShadow: enabled ? <BoxShadow>[BoxShadow(color: const Color(0xFFE0A94E).withOpacity(0.28), blurRadius: 16)] : null,
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: <Widget>[
            Icon(icon, color: Colors.white),
            const SizedBox(width: 8),
            Flexible(child: Text(label, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w900, fontSize: 14.5))),
          ],
        ),
      ),
    );
  }
}

class _MenuButton extends StatelessWidget {
  const _MenuButton({required this.label, required this.icon, required this.onTap});
  final String label;
  final IconData icon;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return InkWell(
      borderRadius: BorderRadius.circular(16),
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 12),
        decoration: BoxDecoration(borderRadius: BorderRadius.circular(16), color: Colors.black.withOpacity(0.24), border: Border.all(color: const Color(0x66E8BD6F))),
        child: Row(mainAxisAlignment: MainAxisAlignment.center, children: <Widget>[Icon(icon, color: const Color(0xFFFFD17A), size: 21), const SizedBox(width: 8), Flexible(child: Text(label, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w800)))]),
      ),
    );
  }
}

class _RoundIconButton extends StatelessWidget {
  const _RoundIconButton({required this.icon, required this.tooltip, required this.onTap});
  final IconData icon;
  final String tooltip;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return Tooltip(
      message: tooltip,
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(35),
        child: Container(
          width: 52,
          height: 52,
          decoration: BoxDecoration(
            shape: BoxShape.circle,
            gradient: const LinearGradient(colors: <Color>[Color(0xFFFFDE91), Color(0xFFB9782A)]),
            border: Border.all(color: const Color(0xFFFFF0C8), width: 2),
            boxShadow: <BoxShadow>[BoxShadow(color: Colors.black.withOpacity(0.35), blurRadius: 14, offset: const Offset(0, 7))],
          ),
          child: Icon(icon, color: const Color(0xFF2E1B08), size: 29),
        ),
      ),
    );
  }
}

class _ResourceTag extends StatelessWidget {
  const _ResourceTag({required this.text});
  final String text;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
      decoration: BoxDecoration(borderRadius: BorderRadius.circular(14), color: Colors.black.withOpacity(0.24), border: Border.all(color: Colors.white.withOpacity(0.22))),
      child: Text(text, style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w800, fontSize: 11.5)),
    );
  }
}

class SplashPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final bg = Paint()..shader = const LinearGradient(begin: Alignment.topLeft, end: Alignment.bottomRight, colors: <Color>[Color(0xFF3B240C), Color(0xFFB98236), Color(0xFF1D1308)]).createShader(Offset.zero & size);
    canvas.drawRect(Offset.zero & size, bg);
    _drawSun(canvas, size, Offset(size.width * 0.84, size.height * 0.18));
    _drawMountains(canvas, size);
    _drawCity(canvas, size, Offset(size.width * 0.60, size.height * 0.57));
    _drawMarket(canvas, size);
    _drawResources(canvas, size);
    _drawMapSilhouette(canvas, size);
  }

  void _drawSun(Canvas canvas, Size size, Offset center) {
    canvas.drawCircle(center, 72, Paint()..color = const Color(0x33FFE1A1));
    canvas.drawCircle(center, 36, Paint()..color = const Color(0x44FFE1A1));
  }

  void _drawMountains(Canvas canvas, Size size) {
    final paint = Paint()..color = const Color(0x665C391B);
    final path = Path()..moveTo(0, size.height * 0.62);
    for (int i = 0; i <= 8; i++) {
      final x = size.width * i / 8;
      path.lineTo(x + size.width / 18, size.height * (0.28 + (i % 3) * 0.07));
      path.lineTo(x + size.width / 8, size.height * 0.62);
    }
    path.lineTo(size.width, size.height);
    path.lineTo(0, size.height);
    path.close();
    canvas.drawPath(path, paint);
  }

  void _drawCity(Canvas canvas, Size size, Offset base) {
    final wall = Paint()..color = const Color(0xFFD2A15A);
    final shadow = Paint()..color = const Color(0x55220E03);
    for (int i = 0; i < 11; i++) {
      final x = base.dx - 380 + i * 76.0;
      final h = 56 + (i % 4) * 18.0;
      final r = Rect.fromLTWH(x, base.dy - h, 56, h);
      canvas.drawRRect(RRect.fromRectAndRadius(r.translate(7, 8), const Radius.circular(4)), shadow);
      canvas.drawRRect(RRect.fromRectAndRadius(r, const Radius.circular(4)), wall);
      canvas.drawRect(Rect.fromLTWH(x + 8, base.dy - h - 20, 40, 22), Paint()..color = const Color(0xFF5D3215));
      canvas.drawCircle(Offset(x + 28, base.dy - h - 22), 22, Paint()..color = const Color(0xFF69A8BE));
    }
  }

  void _drawMarket(Canvas canvas, Size size) {
    final road = Paint()..color = const Color(0x886C4A22);
    final path = Path()
      ..moveTo(size.width * 0.12, size.height * 0.85)
      ..quadraticBezierTo(size.width * 0.42, size.height * 0.67, size.width * 0.84, size.height * 0.88)
      ..lineTo(size.width * 0.84, size.height)
      ..lineTo(size.width * 0.10, size.height)
      ..close();
    canvas.drawPath(path, road);
    final stall = Paint()..color = const Color(0xFFE0B36A);
    for (int i = 0; i < 14; i++) {
      final x = size.width * (0.18 + i * 0.047);
      final y = size.height * (0.66 + (i % 2) * 0.06);
      canvas.drawRRect(RRect.fromRectAndRadius(Rect.fromLTWH(x, y, 52, 26), const Radius.circular(5)), stall);
      canvas.drawRect(Rect.fromLTWH(x + 5, y + 24, 6, 38), Paint()..color = const Color(0xFF5A3314));
      canvas.drawRect(Rect.fromLTWH(x + 40, y + 24, 6, 38), Paint()..color = const Color(0xFF5A3314));
    }
  }

  void _drawResources(Canvas canvas, Size size) {
    final wood = Paint()..color = const Color(0xFF7A451F);
    for (int i = 0; i < 8; i++) {
      canvas.drawRRect(RRect.fromRectAndRadius(Rect.fromLTWH(size.width * 0.09 + i * 18, size.height * 0.76 + (i % 2) * 8, 70, 12), const Radius.circular(8)), wood);
    }
    final stone = Paint()..color = const Color(0xFFB8AA93);
    for (int i = 0; i < 11; i++) {
      canvas.drawRRect(RRect.fromRectAndRadius(Rect.fromLTWH(size.width * 0.26 + (i % 4) * 32, size.height * 0.70 + (i ~/ 4) * 24, 30, 22), const Radius.circular(4)), stone);
    }
    final wheat = Paint()..color = const Color(0xFFE7C058);
    canvas.drawOval(Rect.fromLTWH(size.width * 0.76, size.height * 0.69, 190, 88), wheat);
  }

  void _drawMapSilhouette(Canvas canvas, Size size) {
    final paint = Paint()..color = const Color(0x22FFE6B0)..style = PaintingStyle.stroke..strokeWidth = 4;
    final path = Path()
      ..moveTo(size.width * 0.20, size.height * 0.12)
      ..cubicTo(size.width * 0.33, size.height * 0.06, size.width * 0.42, size.height * 0.12, size.width * 0.50, size.height * 0.20)
      ..cubicTo(size.width * 0.57, size.height * 0.30, size.width * 0.45, size.height * 0.37, size.width * 0.36, size.height * 0.34)
      ..cubicTo(size.width * 0.25, size.height * 0.31, size.width * 0.17, size.height * 0.25, size.width * 0.20, size.height * 0.12);
    canvas.drawPath(path, paint);
  }

  @override
  bool shouldRepaint(covariant SplashPainter oldDelegate) => false;
}

class ParchmentBackgroundPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final gradient = Paint()..shader = const LinearGradient(begin: Alignment.topLeft, end: Alignment.bottomRight, colors: <Color>[Color(0xFF2B1B0B), Color(0xFF4A2D10), Color(0xFF150D05)]).createShader(Offset.zero & size);
    canvas.drawRect(Offset.zero & size, gradient);
    final gridPaint = Paint()..color = Colors.white.withOpacity(0.035)..strokeWidth = 1;
    for (double x = -size.height; x < size.width; x += 52) {
      canvas.drawLine(Offset(x, 0), Offset(x + size.height, size.height), gridPaint);
    }
    for (double x = 0; x < size.width + size.height; x += 52) {
      canvas.drawLine(Offset(x, 0), Offset(x - size.height, size.height), gridPaint);
    }
  }

  @override
  bool shouldRepaint(covariant ParchmentBackgroundPainter oldDelegate) => false;
}

class IranMapPainter extends CustomPainter {
  IranMapPainter({this.selected});
  final RegionData? selected;

  @override
  void paint(Canvas canvas, Size size) {
    final rect = Rect.fromLTWH(size.width * 0.10, size.height * 0.20, size.width * 0.78, size.height * 0.66);
    final mapPath = Path()
      ..moveTo(rect.left + rect.width * 0.11, rect.top + rect.height * 0.39)
      ..cubicTo(rect.left + rect.width * 0.20, rect.top + rect.height * 0.07, rect.left + rect.width * 0.49, rect.top - rect.height * 0.02, rect.left + rect.width * 0.77, rect.top + rect.height * 0.12)
      ..cubicTo(rect.left + rect.width * 0.98, rect.top + rect.height * 0.27, rect.right, rect.top + rect.height * 0.60, rect.left + rect.width * 0.80, rect.bottom * 0.98)
      ..cubicTo(rect.left + rect.width * 0.55, rect.bottom + rect.height * 0.05, rect.left + rect.width * 0.30, rect.bottom - rect.height * 0.06, rect.left + rect.width * 0.17, rect.top + rect.height * 0.72)
      ..cubicTo(rect.left - rect.width * 0.05, rect.top + rect.height * 0.61, rect.left + rect.width * 0.02, rect.top + rect.height * 0.48, rect.left + rect.width * 0.11, rect.top + rect.height * 0.39)
      ..close();

    canvas.save();
    canvas.clipPath(mapPath);
    _paintRegion(canvas, Rect.fromLTWH(rect.left, rect.top, rect.width, rect.height * 0.5), regionById(RegionId.north));
    _paintRegion(canvas, Rect.fromLTWH(rect.left, rect.center.dy, rect.width, rect.height * 0.5), regionById(RegionId.south));
    _paintRegion(canvas, Rect.fromLTWH(rect.left, rect.top, rect.width * 0.5, rect.height), regionById(RegionId.west));
    _paintRegion(canvas, Rect.fromLTWH(rect.center.dx, rect.top, rect.width * 0.5, rect.height), regionById(RegionId.east));
    canvas.restore();

    final border = Paint()..style = PaintingStyle.stroke..strokeWidth = 5..color = const Color(0xCCFFE1A1);
    canvas.drawPath(mapPath, border);
    final inner = Paint()..style = PaintingStyle.stroke..strokeWidth = 2..color = const Color(0x88603616);
    canvas.drawPath(mapPath, inner);
    final cross = Paint()..color = const Color(0xAAFFE1A1)..strokeWidth = 5;
    canvas.drawLine(Offset(rect.center.dx, rect.top + 14), Offset(rect.center.dx, rect.bottom - 14), cross);
    canvas.drawLine(Offset(rect.left + 24, rect.center.dy), Offset(rect.right - 24, rect.center.dy), cross);
    canvas.drawRect(Rect.fromCenter(center: rect.center, width: 34, height: 34), Paint()..color = const Color(0xAAFFE1A1));
    if (selected != null) _drawSelectedGlow(canvas, rect, selected!);
  }

  void _paintRegion(Canvas canvas, Rect rect, RegionData data) {
    final paint = Paint()..shader = LinearGradient(colors: <Color>[data.color.withOpacity(0.55), data.secondaryColor.withOpacity(0.50)]).createShader(rect);
    canvas.drawRect(rect, paint);
  }

  void _drawSelectedGlow(Canvas canvas, Rect rect, RegionData data) {
    final center = switch (data.id) {
      RegionId.north => Offset(rect.center.dx, rect.top + rect.height * 0.22),
      RegionId.south => Offset(rect.center.dx, rect.bottom - rect.height * 0.18),
      RegionId.west => Offset(rect.left + rect.width * 0.22, rect.center.dy),
      RegionId.east => Offset(rect.right - rect.width * 0.22, rect.center.dy),
    };
    canvas.drawCircle(center, 96, Paint()..color = data.color.withOpacity(0.20)..maskFilter = const MaskFilter.blur(BlurStyle.normal, 20));
  }

  @override
  bool shouldRepaint(covariant IranMapPainter oldDelegate) => oldDelegate.selected != selected;
}

class GuideCharacterPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final cx = size.width / 2;
    final base = size.height * 0.86;
    final robe = Paint()..color = const Color(0xFF9F6A32);
    final trim = Paint()..color = const Color(0xFFFFD17A);
    canvas.drawOval(Rect.fromCenter(center: Offset(cx, size.height * 0.27), width: size.width * 0.30, height: size.width * 0.30), Paint()..color = const Color(0xFFD49A62));
    canvas.drawPath(Path()..moveTo(cx, size.height * 0.38)..lineTo(cx - size.width * 0.28, base)..lineTo(cx + size.width * 0.28, base)..close(), robe);
    canvas.drawLine(Offset(cx, size.height * 0.42), Offset(cx, base), trim..strokeWidth = 3);
    canvas.drawOval(Rect.fromCenter(center: Offset(cx, size.height * 0.20), width: size.width * 0.44, height: size.height * 0.14), Paint()..color = const Color(0xFF5A3415));
    canvas.drawCircle(Offset(cx - 7, size.height * 0.27), 2.2, Paint()..color = Colors.black);
    canvas.drawCircle(Offset(cx + 7, size.height * 0.27), 2.2, Paint()..color = Colors.black);
  }

  @override
  bool shouldRepaint(covariant GuideCharacterPainter oldDelegate) => false;
}

class CloudPainter extends CustomPainter {
  CloudPainter({required this.alignment});
  final Alignment alignment;

  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()..color = const Color(0xE6FFFFFF)..maskFilter = const MaskFilter.blur(BlurStyle.normal, 20);
    final side = alignment.x < 0 ? -0.1 : 1.1;
    for (int i = 0; i < 16; i++) {
      final y = size.height * (0.08 + i * 0.06);
      final x = size.width * side + (alignment.x < 0 ? 1 : -1) * (30 + (i % 5) * 36);
      canvas.drawCircle(Offset(x, y), 100 + (i % 4) * 22, paint);
    }
  }

  @override
  bool shouldRepaint(covariant CloudPainter oldDelegate) => false;
}

class RegionLandPainter extends CustomPainter {
  RegionLandPainter({required this.region});
  final RegionData region;

  @override
  void paint(Canvas canvas, Size size) {
    final colors = switch (region.id) {
      RegionId.north => const <Color>[Color(0xFF4B7449), Color(0xFF9B7A3C), Color(0xFF2E2614)],
      RegionId.south => const <Color>[Color(0xFFB77B37), Color(0xFF8D5E2E), Color(0xFF2C1708)],
      RegionId.west => const <Color>[Color(0xFF5F6B3B), Color(0xFF8A6C43), Color(0xFF24170B)],
      RegionId.east => const <Color>[Color(0xFF9A7A3B), Color(0xFF7A4C62), Color(0xFF26120C)],
    };
    canvas.drawRect(Offset.zero & size, Paint()..shader = LinearGradient(begin: Alignment.topCenter, end: Alignment.bottomCenter, colors: colors).createShader(Offset.zero & size));
    _drawTerrain(canvas, size);
    _drawRoads(canvas, size);
    _drawBuildings(canvas, size);
  }

  void _drawTerrain(Canvas canvas, Size size) {
    final hill = Paint()..color = Colors.black.withOpacity(0.13);
    for (int i = 0; i < 7; i++) {
      canvas.drawOval(Rect.fromCenter(center: Offset(size.width * (0.1 + i * 0.15), size.height * (0.78 + (i % 2) * 0.06)), width: 260, height: 70), hill);
    }
    if (region.id == RegionId.north) {
      for (int i = 0; i < 22; i++) _tree(canvas, Offset(size.width * (0.08 + (i % 11) * 0.075), size.height * (0.20 + (i ~/ 11) * 0.14)));
    } else if (region.id == RegionId.south) {
      for (int i = 0; i < 12; i++) _stone(canvas, Offset(size.width * (0.14 + (i % 6) * 0.08), size.height * (0.22 + (i ~/ 6) * 0.12)));
    } else if (region.id == RegionId.west) {
      for (int i = 0; i < 12; i++) _mount(canvas, Offset(size.width * (0.08 + i * 0.07), size.height * 0.18));
    } else {
      for (int i = 0; i < 8; i++) _caravanMark(canvas, Offset(size.width * (0.18 + i * 0.08), size.height * 0.24));
    }
  }

  void _drawRoads(Canvas canvas, Size size) {
    final road = Paint()..color = const Color(0x99643C18)..style = PaintingStyle.stroke..strokeWidth = 34..strokeCap = StrokeCap.round;
    final path = Path()..moveTo(size.width * 0.12, size.height * 0.74)..quadraticBezierTo(size.width * 0.45, size.height * 0.46, size.width * 0.84, size.height * 0.72);
    canvas.drawPath(path, road);
    canvas.drawPath(path, Paint()..color = const Color(0x55F2C875)..style = PaintingStyle.stroke..strokeWidth = 6..strokeCap = StrokeCap.round);
  }

  void _drawBuildings(Canvas canvas, Size size) {
    _building(canvas, Offset(size.width * 0.34, size.height * 0.44), const Color(0xFFB9824A), 'خانه');
    _building(canvas, Offset(size.width * 0.50, size.height * 0.43), const Color(0xFFDCA858), 'بازار');
    _building(canvas, Offset(size.width * 0.66, size.height * 0.45), const Color(0xFF909661), 'انبار');
    _building(canvas, Offset(size.width * 0.48, size.height * 0.24), region.color, region.id == RegionId.south ? 'معدن' : region.id == RegionId.north ? 'جنگل' : region.id == RegionId.east ? 'کاروان' : 'کوه');
  }

  void _building(Canvas canvas, Offset center, Color color, String label) {
    final body = Rect.fromCenter(center: center, width: 110, height: 62);
    canvas.drawRRect(RRect.fromRectAndRadius(body.translate(6, 8), const Radius.circular(8)), Paint()..color = const Color(0x55200D03));
    canvas.drawRRect(RRect.fromRectAndRadius(body, const Radius.circular(8)), Paint()..color = color);
    final roof = Path()..moveTo(body.left - 8, body.top + 4)..lineTo(body.center.dx, body.top - 36)..lineTo(body.right + 8, body.top + 4)..close();
    canvas.drawPath(roof, Paint()..color = const Color(0xFF4A2A11));
    final tp = TextPainter(text: TextSpan(text: label, style: const TextStyle(color: Colors.white, fontSize: 12, fontWeight: FontWeight.bold)), textDirection: TextDirection.rtl)..layout();
    tp.paint(canvas, Offset(body.center.dx - tp.width / 2, body.center.dy - 8));
  }

  void _tree(Canvas canvas, Offset o) {
    canvas.drawRect(Rect.fromLTWH(o.dx - 4, o.dy + 14, 8, 22), Paint()..color = const Color(0xFF5B3217));
    canvas.drawCircle(o, 24, Paint()..color = const Color(0xFF3E7B45));
  }

  void _stone(Canvas canvas, Offset o) => canvas.drawRRect(RRect.fromRectAndRadius(Rect.fromCenter(center: o, width: 50, height: 34), const Radius.circular(8)), Paint()..color = const Color(0xFFC7B79B));

  void _mount(Canvas canvas, Offset o) {
    final p = Path()..moveTo(o.dx - 42, o.dy + 46)..lineTo(o.dx, o.dy - 30)..lineTo(o.dx + 42, o.dy + 46)..close();
    canvas.drawPath(p, Paint()..color = const Color(0xFF6D624A));
  }

  void _caravanMark(Canvas canvas, Offset o) {
    canvas.drawCircle(o, 12, Paint()..color = const Color(0xFFE1A94B));
    canvas.drawLine(o + const Offset(12, 0), o + const Offset(42, 8), Paint()..color = const Color(0xFFE1A94B)..strokeWidth = 4);
  }

  @override
  bool shouldRepaint(covariant RegionLandPainter oldDelegate) => oldDelegate.region != region;
}
