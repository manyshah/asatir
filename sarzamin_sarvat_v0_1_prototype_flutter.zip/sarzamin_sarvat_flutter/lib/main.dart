import 'dart:async';
import 'dart:math' as math;

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:shared_preferences/shared_preferences.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await SystemChrome.setPreferredOrientations(const <DeviceOrientation>[
    DeviceOrientation.landscapeLeft,
    DeviceOrientation.landscapeRight,
  ]);
  await SystemChrome.setEnabledSystemUIMode(SystemUiMode.immersiveSticky);
  runApp(const SarzaminSarvatApp());
}

class SarzaminSarvatApp extends StatelessWidget {
  const SarzaminSarvatApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'سرزمین ثروت',
      theme: ThemeData(
        useMaterial3: true,
        fontFamily: 'sans',
        brightness: Brightness.dark,
        scaffoldBackgroundColor: const Color(0xFF1B1208),
      ),
      builder: (context, child) {
        return Directionality(
          textDirection: TextDirection.rtl,
          child: child ?? const SizedBox.shrink(),
        );
      },
      home: const SplashScreen(),
    );
  }
}

enum RegionId { north, south, west, east }

class RegionData {
  const RegionData({
    required this.id,
    required this.title,
    required this.shortTitle,
    required this.description,
    required this.resources,
    required this.opportunity,
    required this.challenge,
    required this.style,
    required this.color,
    required this.secondaryColor,
  });

  final RegionId id;
  final String title;
  final String shortTitle;
  final String description;
  final List<String> resources;
  final String opportunity;
  final String challenge;
  final String style;
  final Color color;
  final Color secondaryColor;
}

const List<RegionData> kRegions = <RegionData>[
  RegionData(
    id: RegionId.north,
    title: 'منطقه شمال و شمال‌مرکز',
    shortTitle: 'شمال',
    description: 'تهران، البرز، قزوین، گیلان، مازندران و گلستان. منطقه‌ای با بازار مصرف قوی، غذا و چوب بیشتر، اما معدن کمتر و هزینه ساخت بالاتر.',
    resources: <String>['چوب', 'غذا', 'محصول کشاورزی', 'بازار فروش'],
    opportunity: 'فروش محصولات مصرفی، تجارت شهری و کشاورزی سریع‌تر.',
    challenge: 'معدن ضعیف‌تر، زمین گران‌تر و رقابت بیشتر.',
    style: 'کشاورزی، چوب، بازار مصرف و رشد تجاری آرام.',
    color: Color(0xFF57B26A),
    secondaryColor: Color(0xFF2D6B4B),
  ),
  RegionData(
    id: RegionId.south,
    title: 'منطقه جنوب',
    shortTitle: 'جنوب',
    description: 'سیستان و بلوچستان، هرمزگان، بوشهر، خوزستان و جنوب کرمان. منطقه‌ای خشک‌تر با معدن، مصالح و مسیرهای بندری.',
    resources: <String>['سنگ', 'آهن', 'مصالح', 'تجارت دریایی'],
    opportunity: 'استخراج معدن، فروش مصالح، کالاهای بندری و تجارت سنگین.',
    challenge: 'چوب و کشاورزی محدودتر و نیاز بیشتر به مدیریت غذا.',
    style: 'معدن، بندر، مصالح و تجارت دوربرد.',
    color: Color(0xFFD89636),
    secondaryColor: Color(0xFF8B5A28),
  ),
  RegionData(
    id: RegionId.west,
    title: 'منطقه غرب',
    shortTitle: 'غرب',
    description: 'کردستان، کرمانشاه، ایلام، لرستان، همدان و آذربایجان غربی. منطقه‌ای کوهستانی با دامداری، سنگ و چوب متوسط.',
    resources: <String>['دامداری', 'پوست', 'سنگ', 'چوب متوسط'],
    opportunity: 'تولید محصولات دامی، سنگ، کارگاه‌های سنتی و تجارت منطقه‌ای.',
    challenge: 'بازار فروش کوچک‌تر و مسیرهای تجاری کندتر از مرکز.',
    style: 'دامداری، سنگ، کارگاه و رشد پایدار.',
    color: Color(0xFF8C9A4C),
    secondaryColor: Color(0xFF4D5B2C),
  ),
  RegionData(
    id: RegionId.east,
    title: 'منطقه شرق',
    shortTitle: 'شرق',
    description: 'خراسان‌ها، یزد، کرمان و نواحی شرقی. منطقه‌ای با زعفران، کالاهای خاص، معادن و مسیرهای کاروانی.',
    resources: <String>['زعفران', 'معدن', 'کالاهای خاص', 'کاروان'],
    opportunity: 'تجارت کاروانی، کالاهای ارزشمند کم‌حجم و بازار خاص.',
    challenge: 'آب و چوب کمتر و وابستگی بیشتر به مسیرهای تجارت.',
    style: 'زعفران، کاروان، معدن و تجارت تخصصی.',
    color: Color(0xFFB678D8),
    secondaryColor: Color(0xFF6F3B8D),
  ),
];

RegionData regionById(RegionId id) => kRegions.firstWhere((region) => region.id == id);
RegionData regionByName(String? name) {
  for (final region in kRegions) {
    if (region.id.name == name) return region;
  }
  return kRegions.first;
}

class GameStorage {
  static const String _guestIdKey = 'guest_id';
  static const String _regionKey = 'selected_region';
  static const String _coinsKey = 'coins';
  static const String _woodKey = 'wood';
  static const String _stoneKey = 'stone';
  static const String _ironKey = 'iron';
  static const String _foodKey = 'food';

  static Future<String> ensureGuest() async {
    final prefs = await SharedPreferences.getInstance();
    final saved = prefs.getString(_guestIdKey);
    if (saved != null && saved.isNotEmpty) return saved;
    final random = math.Random().nextInt(999999);
    final id = 'guest_${DateTime.now().millisecondsSinceEpoch}_$random';
    await prefs.setString(_guestIdKey, id);
    await prefs.setInt(_coinsKey, 120);
    await prefs.setInt(_woodKey, 8);
    await prefs.setInt(_stoneKey, 5);
    await prefs.setInt(_ironKey, 2);
    await prefs.setInt(_foodKey, 12);
    return id;
  }

  static Future<void> saveRegion(RegionId id) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(_regionKey, id.name);
  }

  static Future<RegionData?> loadRegion() async {
    final prefs = await SharedPreferences.getInstance();
    final regionName = prefs.getString(_regionKey);
    if (regionName == null) return null;
    return regionByName(regionName);
  }

  static Future<Map<String, int>> loadResources() async {
    final prefs = await SharedPreferences.getInstance();
    return <String, int>{
      'coin': prefs.getInt(_coinsKey) ?? 120,
      'wood': prefs.getInt(_woodKey) ?? 8,
      'stone': prefs.getInt(_stoneKey) ?? 5,
      'iron': prefs.getInt(_ironKey) ?? 2,
      'food': prefs.getInt(_foodKey) ?? 12,
    };
  }

  static Future<void> saveResources(Map<String, int> resources) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setInt(_coinsKey, resources['coin'] ?? 0);
    await prefs.setInt(_woodKey, resources['wood'] ?? 0);
    await prefs.setInt(_stoneKey, resources['stone'] ?? 0);
    await prefs.setInt(_ironKey, resources['iron'] ?? 0);
    await prefs.setInt(_foodKey, resources['food'] ?? 0);
  }
}

class SplashScreen extends StatefulWidget {
  const SplashScreen({super.key});

  @override
  State<SplashScreen> createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen> with SingleTickerProviderStateMixin {
  late final AnimationController _controller;

  @override
  void initState() {
    super.initState();
    SystemChrome.setEnabledSystemUIMode(SystemUiMode.immersiveSticky);
    _controller = AnimationController(vsync: this, duration: const Duration(milliseconds: 2500));
    _prepare();
  }

  Future<void> _prepare() async {
    await GameStorage.ensureGuest();
    if (!mounted) return;
    unawaited(_controller.forward());
    await Future<void>.delayed(const Duration(milliseconds: 2700));
    if (!mounted) return;
    final savedRegion = await GameStorage.loadRegion();
    if (!mounted) return;
    await Navigator.of(context).pushReplacement(
      PageRouteBuilder(
        transitionDuration: const Duration(milliseconds: 650),
        pageBuilder: (_, animation, __) => FadeTransition(
          opacity: animation,
          child: StartMapScreen(savedRegion: savedRegion),
        ),
      ),
    );
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Stack(
        fit: StackFit.expand,
        children: <Widget>[
          CustomPaint(painter: SplashPainter()),
          Container(
            decoration: const BoxDecoration(
              gradient: LinearGradient(
                begin: Alignment.topCenter,
                end: Alignment.bottomCenter,
                colors: <Color>[Color(0x66000000), Color(0x11000000), Color(0xAA1B1208)],
              ),
            ),
          ),
          Center(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: <Widget>[
                Text(
                  'سرزمین ثروت',
                  style: TextStyle(
                    fontSize: 54,
                    fontWeight: FontWeight.w900,
                    letterSpacing: -1,
                    color: const Color(0xFFFFE1A1),
                    shadows: <Shadow>[
                      Shadow(color: Colors.black.withOpacity(0.8), blurRadius: 18, offset: const Offset(0, 5)),
                    ],
                  ),
                ),
                const SizedBox(height: 10),
                Text(
                  'تجارت کن، منابع بساز، ثروتت را گسترش بده',
                  style: TextStyle(color: Colors.white.withOpacity(0.86), fontSize: 18, fontWeight: FontWeight.w600),
                ),
              ],
            ),
          ),
          Align(
            alignment: Alignment.bottomCenter,
            child: Padding(
              padding: const EdgeInsets.only(bottom: 34, left: 230, right: 230),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: <Widget>[
                  ClipRRect(
                    borderRadius: BorderRadius.circular(20),
                    child: AnimatedBuilder(
                      animation: _controller,
                      builder: (context, _) {
                        return LinearProgressIndicator(
                          value: _controller.value,
                          minHeight: 11,
                          backgroundColor: const Color(0xFF4A341C),
                          valueColor: const AlwaysStoppedAnimation<Color>(Color(0xFFFFC95C)),
                        );
                      },
                    ),
                  ),
                  const SizedBox(height: 10),
                  Text('آماده‌سازی نقشه و اقتصاد بازی...', style: TextStyle(color: Colors.white.withOpacity(0.72))),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class StartMapScreen extends StatefulWidget {
  const StartMapScreen({super.key, this.savedRegion});

  final RegionData? savedRegion;

  @override
  State<StartMapScreen> createState() => _StartMapScreenState();
}

class _StartMapScreenState extends State<StartMapScreen> {
  RegionData? _selected;
  bool _showReveal = false;

  @override
  void initState() {
    super.initState();
    SystemChrome.setEnabledSystemUIMode(SystemUiMode.immersiveSticky);
    _selected = widget.savedRegion;
  }

  Future<void> _openSettings() async {
    await showDialog<void>(
      context: context,
      builder: (_) => const SettingsDialog(),
    );
    await SystemChrome.setEnabledSystemUIMode(SystemUiMode.immersiveSticky);
  }

  Future<void> _showRegionInfo(RegionData data) async {
    await showDialog<void>(
      context: context,
      builder: (_) => RegionInfoDialog(data: data),
    );
  }

  Future<void> _startRegion(RegionData region) async {
    await GameStorage.saveRegion(region.id);
    setState(() => _showReveal = true);
  }

  void _finishReveal() {
    final region = _selected ?? kRegions.first;
    Navigator.of(context).pushReplacement(
      PageRouteBuilder(
        transitionDuration: const Duration(milliseconds: 500),
        pageBuilder: (_, animation, __) => FadeTransition(
          opacity: animation,
          child: PlayerLandScreen(region: region),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final selected = _selected;
    return Scaffold(
      body: Stack(
        fit: StackFit.expand,
        children: <Widget>[
          CustomPaint(painter: ParchmentBackgroundPainter()),
          SafeArea(
            child: Padding(
              padding: const EdgeInsets.fromLTRB(16, 12, 16, 12),
              child: Row(
                textDirection: TextDirection.ltr,
                children: <Widget>[
                  Expanded(
                    flex: 74,
                    child: _MapBoard(
                      selected: selected,
                      onSelect: (region) => setState(() => _selected = region),
                      onInfo: _showRegionInfo,
                    ),
                  ),
                  const SizedBox(width: 14),
                  Expanded(
                    flex: 26,
                    child: _GuidePanel(
                      selected: selected,
                      hasSavedRegion: widget.savedRegion != null,
                      onStart: selected == null ? null : () => _startRegion(selected),
                    ),
                  ),
                ],
              ),
            ),
          ),
          Positioned(
            top: 14,
            left: 18,
            child: _RoundIconButton(
              icon: Icons.settings_rounded,
              tooltip: 'تنظیمات',
              onTap: _openSettings,
            ),
          ),
          Positioned(
            top: 14,
            right: 22,
            child: _TitleChip(
              title: 'انتخاب سرزمین شروع',
              subtitle: 'هر منطقه مسیر اقتصادی خودش را دارد؛ قدرت نهایی برابر، راه رسیدن متفاوت.',
            ),
          ),
          if (_showReveal)
            RevealOverlay(
              region: _selected ?? kRegions.first,
              onFinished: _finishReveal,
            ),
        ],
      ),
    );
  }
}

class _MapBoard extends StatelessWidget {
  const _MapBoard({required this.selected, required this.onSelect, required this.onInfo});

  final RegionData? selected;
  final ValueChanged<RegionData> onSelect;
  final ValueChanged<RegionData> onInfo;

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(26),
        border: Border.all(color: const Color(0xFFE4B663), width: 2),
        boxShadow: <BoxShadow>[
          BoxShadow(color: Colors.black.withOpacity(0.35), blurRadius: 22, offset: const Offset(0, 12)),
        ],
      ),
      clipBehavior: Clip.antiAlias,
      child: Stack(
        fit: StackFit.expand,
        children: <Widget>[
          CustomPaint(painter: IranMapPainter(selected: selected)),
          _RegionHotspot(
            region: regionById(RegionId.north),
            rect: const AlignmentRect(Alignment.topCenter, widthFactor: 0.46, heightFactor: 0.42),
            onSelect: onSelect,
            onInfo: onInfo,
          ),
          _RegionHotspot(
            region: regionById(RegionId.south),
            rect: const AlignmentRect(Alignment.bottomCenter, widthFactor: 0.52, heightFactor: 0.42),
            onSelect: onSelect,
            onInfo: onInfo,
          ),
          _RegionHotspot(
            region: regionById(RegionId.west),
            rect: const AlignmentRect(Alignment.centerLeft, widthFactor: 0.42, heightFactor: 0.62),
            onSelect: onSelect,
            onInfo: onInfo,
          ),
          _RegionHotspot(
            region: regionById(RegionId.east),
            rect: const AlignmentRect(Alignment.centerRight, widthFactor: 0.42, heightFactor: 0.62),
            onSelect: onSelect,
            onInfo: onInfo,
          ),
          const Center(
            child: IgnorePointer(
              child: Text(
                '+',
                style: TextStyle(fontSize: 72, fontWeight: FontWeight.w900, color: Color(0xBBFADFA1)),
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class AlignmentRect {
  const AlignmentRect(this.alignment, {required this.widthFactor, required this.heightFactor});

  final Alignment alignment;
  final double widthFactor;
  final double heightFactor;
}

class _RegionHotspot extends StatelessWidget {
  const _RegionHotspot({required this.region, required this.rect, required this.onSelect, required this.onInfo});

  final RegionData region;
  final AlignmentRect rect;
  final ValueChanged<RegionData> onSelect;
  final ValueChanged<RegionData> onInfo;

  @override
  Widget build(BuildContext context) {
    return Align(
      alignment: rect.alignment,
      child: FractionallySizedBox(
        widthFactor: rect.widthFactor,
        heightFactor: rect.heightFactor,
        child: GestureDetector(
          behavior: HitTestBehavior.translucent,
          onTap: () => onSelect(region),
          child: Stack(
            children: <Widget>[
              Align(
                alignment: Alignment.center,
                child: Container(
                  padding: const EdgeInsets.symmetric(horizontal: 13, vertical: 7),
                  decoration: BoxDecoration(
                    color: Colors.black.withOpacity(0.32),
                    borderRadius: BorderRadius.circular(24),
                    border: Border.all(color: region.color.withOpacity(0.85)),
                  ),
                  child: Text(
                    region.shortTitle,
                    style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w900, fontSize: 18),
                  ),
                ),
              ),
              Align(
                alignment: Alignment.topRight,
                child: Padding(
                  padding: const EdgeInsets.all(8),
                  child: InkWell(
                    onTap: () => onInfo(region),
                    borderRadius: BorderRadius.circular(30),
                    child: Container(
                      width: 36,
                      height: 36,
                      decoration: BoxDecoration(
                        color: const Color(0xFFE5B560),
                        shape: BoxShape.circle,
                        border: Border.all(color: const Color(0xFFFFE3A4), width: 2),
                        boxShadow: <BoxShadow>[BoxShadow(color: Colors.black.withOpacity(0.4), blurRadius: 8)],
                      ),
                      child: const Icon(Icons.question_mark_rounded, color: Color(0xFF34200C), size: 22),
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _GuidePanel extends StatelessWidget {
  const _GuidePanel({required this.selected, required this.hasSavedRegion, required this.onStart});

  final RegionData? selected;
  final bool hasSavedRegion;
  final VoidCallback? onStart;

  @override
  Widget build(BuildContext context) {
    final region = selected;
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(26),
        color: const Color(0xD31F160D),
        border: Border.all(color: const Color(0xFFE4B663), width: 1.5),
        boxShadow: <BoxShadow>[BoxShadow(color: Colors.black.withOpacity(0.35), blurRadius: 20, offset: const Offset(0, 10))],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: <Widget>[
          Expanded(
            child: Container(
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(20),
                gradient: const LinearGradient(
                  begin: Alignment.topCenter,
                  end: Alignment.bottomCenter,
                  colors: <Color>[Color(0xFF4B3017), Color(0xFF271609)],
                ),
              ),
              child: CustomPaint(
                painter: GuideCharacterPainter(),
                child: const Align(
                  alignment: Alignment.bottomCenter,
                  child: Padding(
                    padding: EdgeInsets.all(10),
                    child: Text('جای کاراکتر راهنما', style: TextStyle(color: Color(0xFFFFD98A), fontWeight: FontWeight.w800)),
                  ),
                ),
              ),
            ),
          ),
          const SizedBox(height: 12),
          Text(
            'راهنمای شروع',
            style: TextStyle(color: const Color(0xFFFFE1A1), fontSize: 20, fontWeight: FontWeight.w900, shadows: <Shadow>[Shadow(color: Colors.black.withOpacity(0.8), blurRadius: 8)]),
          ),
          const SizedBox(height: 8),
          Text(
            'هر منطقه منابع و فرصت‌های مخصوص خودش را دارد. مسیر ثروت فرق می‌کند، اما شانس پیشرفت برای همه برابر است.',
            style: TextStyle(color: Colors.white.withOpacity(0.82), height: 1.55, fontSize: 13.5),
          ),
          const SizedBox(height: 12),
          AnimatedSwitcher(
            duration: const Duration(milliseconds: 250),
            child: region == null
                ? _SmallHintBox(text: hasSavedRegion ? 'منطقه قبلی ذخیره شده. می‌توانی ادامه بدهی یا منطقه جدید انتخاب کنی.' : 'برای شروع یکی از چهار منطقه نقشه را انتخاب کن.')
                : _SelectedRegionCard(region: region),
          ),
          const SizedBox(height: 12),
          _PrimaryGameButton(
            label: region == null ? 'ابتدا منطقه را انتخاب کن' : (hasSavedRegion ? 'ادامه / ورود به ${region.shortTitle}' : 'شروع از ${region.shortTitle}'),
            icon: Icons.play_arrow_rounded,
            onTap: onStart,
          ),
        ],
      ),
    );
  }
}

class _SmallHintBox extends StatelessWidget {
  const _SmallHintBox({required this.text});

  final String text;

  @override
  Widget build(BuildContext context) {
    return Container(
      key: ValueKey<String>(text),
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(16),
        color: const Color(0xFF32220F),
        border: Border.all(color: const Color(0x775D4528)),
      ),
      child: Text(text, style: TextStyle(color: Colors.white.withOpacity(0.78), fontSize: 13, height: 1.45)),
    );
  }
}

class _SelectedRegionCard extends StatelessWidget {
  const _SelectedRegionCard({required this.region});

  final RegionData region;

  @override
  Widget build(BuildContext context) {
    return Container(
      key: ValueKey<RegionId>(region.id),
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(16),
        gradient: LinearGradient(colors: <Color>[region.secondaryColor.withOpacity(0.85), const Color(0xFF24170B)]),
        border: Border.all(color: region.color.withOpacity(0.8)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          Text(region.title, style: const TextStyle(color: Colors.white, fontSize: 15, fontWeight: FontWeight.w900)),
          const SizedBox(height: 8),
          Wrap(
            spacing: 6,
            runSpacing: 6,
            children: region.resources.take(4).map((item) => _ResourceTag(text: item)).toList(),
          ),
        ],
      ),
    );
  }
}

class RegionInfoDialog extends StatelessWidget {
  const RegionInfoDialog({super.key, required this.data});

  final RegionData data;

  @override
  Widget build(BuildContext context) {
    return Dialog(
      backgroundColor: Colors.transparent,
      child: Container(
        width: 620,
        padding: const EdgeInsets.all(20),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(28),
          gradient: const LinearGradient(
            begin: Alignment.topRight,
            end: Alignment.bottomLeft,
            colors: <Color>[Color(0xFF4B3017), Color(0xFF201207)],
          ),
          border: Border.all(color: const Color(0xFFE8BD6F), width: 2),
          boxShadow: <BoxShadow>[BoxShadow(color: Colors.black.withOpacity(0.55), blurRadius: 26, offset: const Offset(0, 14))],
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: <Widget>[
            Row(
              children: <Widget>[
                CircleAvatar(backgroundColor: data.color, child: const Icon(Icons.public_rounded, color: Colors.white)),
                const SizedBox(width: 12),
                Expanded(child: Text(data.title, style: const TextStyle(fontSize: 23, fontWeight: FontWeight.w900, color: Color(0xFFFFE1A1)))),
                IconButton(onPressed: () => Navigator.of(context).pop(), icon: const Icon(Icons.close_rounded, color: Colors.white)),
              ],
            ),
            const SizedBox(height: 12),
            Text(data.description, style: TextStyle(color: Colors.white.withOpacity(0.86), fontSize: 14.5, height: 1.7)),
            const SizedBox(height: 14),
            _InfoSection(title: 'منابع قوی', text: data.resources.join('، '), icon: Icons.inventory_2_rounded),
            _InfoSection(title: 'فرصت اقتصادی', text: data.opportunity, icon: Icons.trending_up_rounded),
            _InfoSection(title: 'چالش', text: data.challenge, icon: Icons.warning_amber_rounded),
            _InfoSection(title: 'سبک پیشرفت', text: data.style, icon: Icons.route_rounded),
            const SizedBox(height: 12),
            _PrimaryGameButton(label: 'متوجه شدم', icon: Icons.check_rounded, onTap: () => Navigator.of(context).pop()),
          ],
        ),
      ),
    );
  }
}

class _InfoSection extends StatelessWidget {
  const _InfoSection({required this.title, required this.text, required this.icon});

  final String title;
  final String text;
  final IconData icon;

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.only(bottom: 8),
      padding: const EdgeInsets.all(10),
      decoration: BoxDecoration(
        color: Colors.black.withOpacity(0.19),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: Colors.white.withOpacity(0.08)),
      ),
      child: Row(
        children: <Widget>[
          Icon(icon, color: const Color(0xFFFFD17A), size: 24),
          const SizedBox(width: 10),
          Expanded(
            child: RichText(
              text: TextSpan(
                style: const TextStyle(fontFamily: 'sans', color: Colors.white, height: 1.45),
                children: <TextSpan>[
                  TextSpan(text: '$title: ', style: const TextStyle(fontWeight: FontWeight.w900, color: Color(0xFFFFE1A1))),
                  TextSpan(text: text, style: TextStyle(color: Colors.white.withOpacity(0.82))),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class SettingsDialog extends StatelessWidget {
  const SettingsDialog({super.key});

  @override
  Widget build(BuildContext context) {
    return Dialog(
      backgroundColor: Colors.transparent,
      child: Container(
        width: 520,
        padding: const EdgeInsets.all(20),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(28),
          gradient: const LinearGradient(colors: <Color>[Color(0xFF4B3017), Color(0xFF1B1008)]),
          border: Border.all(color: const Color(0xFFE8BD6F), width: 2),
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: <Widget>[
            Row(
              children: <Widget>[
                const Icon(Icons.settings_rounded, color: Color(0xFFFFD17A)),
                const SizedBox(width: 10),
                const Expanded(child: Text('تنظیمات', style: TextStyle(color: Color(0xFFFFE1A1), fontSize: 23, fontWeight: FontWeight.w900))),
                IconButton(onPressed: () => Navigator.of(context).pop(), icon: const Icon(Icons.close_rounded, color: Colors.white)),
              ],
            ),
            const SizedBox(height: 12),
            Text(
              'ورود و ثبت‌نام اجباری نیست. می‌توانی چند روز به‌صورت مهمان بازی کنی و بعداً همین پیشرفت را به حساب اصلی وصل کنی.',
              style: TextStyle(color: Colors.white.withOpacity(0.82), height: 1.6),
            ),
            const SizedBox(height: 14),
            Row(
              children: <Widget>[
                Expanded(child: _MenuButton(label: 'ورود', icon: Icons.login_rounded, onTap: () {})),
                const SizedBox(width: 10),
                Expanded(child: _MenuButton(label: 'ثبت‌نام', icon: Icons.person_add_alt_1_rounded, onTap: () {})),
              ],
            ),
            const SizedBox(height: 10),
            _MenuButton(label: 'صدا و موسیقی', icon: Icons.volume_up_rounded, onTap: () {}),
            const SizedBox(height: 10),
            _MenuButton(label: 'پشتیبانی / قوانین', icon: Icons.support_agent_rounded, onTap: () {}),
          ],
        ),
      ),
    );
  }
}

class RevealOverlay extends StatefulWidget {
  const RevealOverlay({super.key, required this.region, required this.onFinished});

  final RegionData region;
  final VoidCallback onFinished;

  @override
  State<RevealOverlay> createState() => _RevealOverlayState();
}

class _RevealOverlayState extends State<RevealOverlay> with SingleTickerProviderStateMixin {
  late final AnimationController _controller;

  @override
  void initState() {
    super.initState();
    _controller = AnimationController(vsync: this, duration: const Duration(milliseconds: 1700));
    _controller.forward();
    _controller.addStatusListener((status) {
      if (status == AnimationStatus.completed) {
        widget.onFinished();
      }
    });
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: _controller,
      builder: (context, _) {
        final t = Curves.easeInOut.transform(_controller.value);
        final flash = (1 - (t - 0.35).abs() * 2).clamp(0.0, 1.0);
        return Stack(
          fit: StackFit.expand,
          children: <Widget>[
            Container(color: Colors.white.withOpacity(0.12 + flash * 0.72)),
            Transform.translate(
              offset: Offset(-MediaQuery.of(context).size.width * t, 0),
              child: CustomPaint(painter: CloudPainter(alignment: Alignment.centerLeft)),
            ),
            Transform.translate(
              offset: Offset(MediaQuery.of(context).size.width * t, 0),
              child: CustomPaint(painter: CloudPainter(alignment: Alignment.centerRight)),
            ),
            Center(
              child: Opacity(
                opacity: (1 - t).clamp(0.0, 1.0),
                child: Text('ورود به ${widget.region.shortTitle}', style: const TextStyle(color: Color(0xFF3B250C), fontSize: 30, fontWeight: FontWeight.w900)),
              ),
            ),
          ],
        );
      },
    );
  }
}

class PlayerLandScreen extends StatefulWidget {
  const PlayerLandScreen({super.key, required this.region});

  final RegionData region;

  @override
  State<PlayerLandScreen> createState() => _PlayerLandScreenState();
}

class _PlayerLandScreenState extends State<PlayerLandScreen> {
  Map<String, int> _resources = <String, int>{'coin': 120, 'wood': 8, 'stone': 5, 'iron': 2, 'food': 12};

  @override
  void initState() {
    super.initState();
    SystemChrome.setEnabledSystemUIMode(SystemUiMode.immersiveSticky);
    _load();
  }

  Future<void> _load() async {
    final resources = await GameStorage.loadResources();
    if (mounted) setState(() => _resources = resources);
  }

  Future<void> _save() async => GameStorage.saveResources(_resources);

  Future<void> _collectMainResource() async {
    final id = widget.region.id;
    setState(() {
      if (id == RegionId.north) {
        _resources['wood'] = (_resources['wood'] ?? 0) + 4;
        _resources['food'] = (_resources['food'] ?? 0) + 2;
      } else if (id == RegionId.south) {
        _resources['stone'] = (_resources['stone'] ?? 0) + 4;
        _resources['iron'] = (_resources['iron'] ?? 0) + 1;
      } else if (id == RegionId.west) {
        _resources['stone'] = (_resources['stone'] ?? 0) + 3;
        _resources['food'] = (_resources['food'] ?? 0) + 2;
      } else {
        _resources['iron'] = (_resources['iron'] ?? 0) + 2;
        _resources['food'] = (_resources['food'] ?? 0) + 1;
      }
    });
    await _save();
  }

  Future<void> _sellBundle() async {
    setState(() {
      final wood = _resources['wood'] ?? 0;
      final stone = _resources['stone'] ?? 0;
      final iron = _resources['iron'] ?? 0;
      final food = _resources['food'] ?? 0;
      if (wood + stone + iron + food <= 0) return;
      final sellWood = math.min(wood, 3);
      final sellStone = math.min(stone, 3);
      final sellIron = math.min(iron, 1);
      final sellFood = math.min(food, 2);
      _resources['wood'] = wood - sellWood;
      _resources['stone'] = stone - sellStone;
      _resources['iron'] = iron - sellIron;
      _resources['food'] = food - sellFood;
      _resources['coin'] = (_resources['coin'] ?? 0) + sellWood * 6 + sellStone * 5 + sellIron * 18 + sellFood * 4;
    });
    await _save();
  }

  Future<void> _openMarket() async {
    await showModalBottomSheet<void>(
      context: context,
      backgroundColor: Colors.transparent,
      builder: (_) => _MarketSheet(resources: _resources, onSell: _sellBundle),
    );
    await SystemChrome.setEnabledSystemUIMode(SystemUiMode.immersiveSticky);
  }

  @override
  Widget build(BuildContext context) {
    final region = widget.region;
    return Scaffold(
      body: Stack(
        fit: StackFit.expand,
        children: <Widget>[
          CustomPaint(painter: RegionLandPainter(region: region)),
          SafeArea(
            child: Column(
              children: <Widget>[
                Padding(
                  padding: const EdgeInsets.fromLTRB(14, 10, 14, 0),
                  child: _ResourceBar(resources: _resources, region: region),
                ),
                Expanded(
                  child: Padding(
                    padding: const EdgeInsets.fromLTRB(18, 8, 18, 6),
                    child: Row(
                      textDirection: TextDirection.ltr,
                      children: <Widget>[
                        Expanded(
                          child: _LandInteractionLayer(
                            region: region,
                            onCollect: _collectMainResource,
                            onMarket: _openMarket,
                          ),
                        ),
                        SizedBox(
                          width: 300,
                          child: _MissionPanel(region: region, onCollect: _collectMainResource, onMarket: _openMarket),
                        ),
                      ],
                    ),
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.fromLTRB(18, 0, 18, 12),
                  child: _BottomGameMenu(onMarket: _openMarket),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _ResourceBar extends StatelessWidget {
  const _ResourceBar({required this.resources, required this.region});

  final Map<String, int> resources;
  final RegionData region;

  @override
  Widget build(BuildContext context) {
    return Container(
      height: 64,
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(22),
        color: const Color(0xDD20140A),
        border: Border.all(color: const Color(0xFFE4B663)),
        boxShadow: <BoxShadow>[BoxShadow(color: Colors.black.withOpacity(0.34), blurRadius: 16, offset: const Offset(0, 8))],
      ),
      child: Row(
        children: <Widget>[
          Expanded(
            child: Text(
              'منطقه ${region.shortTitle}',
              style: const TextStyle(color: Color(0xFFFFE1A1), fontWeight: FontWeight.w900, fontSize: 18),
            ),
          ),
          _ResourcePill(icon: Icons.monetization_on_rounded, label: 'سکه', value: resources['coin'] ?? 0, color: const Color(0xFFFFC857)),
          _ResourcePill(icon: Icons.forest_rounded, label: 'چوب', value: resources['wood'] ?? 0, color: const Color(0xFF7AD37E)),
          _ResourcePill(icon: Icons.terrain_rounded, label: 'سنگ', value: resources['stone'] ?? 0, color: const Color(0xFFC0B7A5)),
          _ResourcePill(icon: Icons.hardware_rounded, label: 'آهن', value: resources['iron'] ?? 0, color: const Color(0xFFB7C4D4)),
          _ResourcePill(icon: Icons.rice_bowl_rounded, label: 'غذا', value: resources['food'] ?? 0, color: const Color(0xFFFFDC84)),
        ],
      ),
    );
  }
}

class _ResourcePill extends StatelessWidget {
  const _ResourcePill({required this.icon, required this.label, required this.value, required this.color});

  final IconData icon;
  final String label;
  final int value;
  final Color color;

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.only(right: 8),
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 7),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(18),
        color: Colors.black.withOpacity(0.24),
        border: Border.all(color: color.withOpacity(0.55)),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: <Widget>[
          Icon(icon, color: color, size: 18),
          const SizedBox(width: 5),
          Text('$label $value', style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w800, fontSize: 12)),
        ],
      ),
    );
  }
}

class _LandInteractionLayer extends StatelessWidget {
  const _LandInteractionLayer({required this.region, required this.onCollect, required this.onMarket});

  final RegionData region;
  final VoidCallback onCollect;
  final VoidCallback onMarket;

  @override
  Widget build(BuildContext context) {
    return Stack(
      children: <Widget>[
        Align(
          alignment: const Alignment(-0.48, 0.02),
          child: _BuildingBubble(title: 'خانه', subtitle: 'سطح ۱', icon: Icons.home_work_rounded, color: const Color(0xFFBC8351), onTap: () {}),
        ),
        Align(
          alignment: const Alignment(0.02, 0.04),
          child: _BuildingBubble(title: 'بازار', subtitle: 'خرید و فروش', icon: Icons.storefront_rounded, color: const Color(0xFFE2A64E), onTap: onMarket),
        ),
        Align(
          alignment: const Alignment(0.48, 0.0),
          child: _BuildingBubble(title: 'انبار', subtitle: 'منابع', icon: Icons.inventory_2_rounded, color: const Color(0xFF87935B), onTap: () {}),
        ),
        Align(
          alignment: const Alignment(-0.1, -0.48),
          child: _BuildingBubble(title: region.id == RegionId.south ? 'معدن' : region.id == RegionId.north ? 'جنگل' : region.id == RegionId.east ? 'کاروان' : 'کوهستان', subtitle: 'جمع‌آوری', icon: Icons.add_business_rounded, color: region.color, onTap: onCollect),
        ),
        Align(
          alignment: const Alignment(0.0, 0.66),
          child: _PrimaryGameButton(label: 'جمع‌آوری منابع', icon: Icons.touch_app_rounded, onTap: onCollect),
        ),
      ],
    );
  }
}

class _BuildingBubble extends StatelessWidget {
  const _BuildingBubble({required this.title, required this.subtitle, required this.icon, required this.color, required this.onTap});

  final String title;
  final String subtitle;
  final IconData icon;
  final Color color;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return InkWell(
      borderRadius: BorderRadius.circular(22),
      onTap: onTap,
      child: Container(
        width: 154,
        padding: const EdgeInsets.all(11),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(22),
          gradient: LinearGradient(colors: <Color>[color.withOpacity(0.92), const Color(0xFF2B1909)]),
          border: Border.all(color: const Color(0xFFFFD27C), width: 1.3),
          boxShadow: <BoxShadow>[BoxShadow(color: Colors.black.withOpacity(0.36), blurRadius: 14, offset: const Offset(0, 8))],
        ),
        child: Row(
          children: <Widget>[
            Icon(icon, color: Colors.white, size: 30),
            const SizedBox(width: 9),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisSize: MainAxisSize.min,
                children: <Widget>[
                  Text(title, style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w900, fontSize: 15)),
                  Text(subtitle, style: TextStyle(color: Colors.white.withOpacity(0.78), fontSize: 11)),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _MissionPanel extends StatelessWidget {
  const _MissionPanel({required this.region, required this.onCollect, required this.onMarket});

  final RegionData region;
  final VoidCallback onCollect;
  final VoidCallback onMarket;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(15),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(24),
        color: const Color(0xDD20140A),
        border: Border.all(color: const Color(0xFFE4B663)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: <Widget>[
          const Text('آموزش شروع', style: TextStyle(color: Color(0xFFFFE1A1), fontWeight: FontWeight.w900, fontSize: 19)),
          const SizedBox(height: 8),
          Text('منطقه ${region.shortTitle} انتخاب شد. این نسخه اولیه است؛ فعلاً منابع جمع کن و در بازار بفروش.', style: TextStyle(color: Colors.white.withOpacity(0.82), height: 1.55, fontSize: 13)),
          const SizedBox(height: 12),
          _StepText(number: 1, text: 'روی منبع اصلی منطقه بزن و آیتم جمع کن.'),
          _StepText(number: 2, text: 'وارد بازار شو و بخشی از منابع را بفروش.'),
          _StepText(number: 3, text: 'در نسخه بعد، کارگاه و تجارت آنلاین اضافه می‌شود.'),
          const Spacer(),
          _PrimaryGameButton(label: 'جمع‌آوری', icon: Icons.handyman_rounded, onTap: onCollect),
          const SizedBox(height: 8),
          _MenuButton(label: 'رفتن به بازار', icon: Icons.store_mall_directory_rounded, onTap: onMarket),
        ],
      ),
    );
  }
}

class _StepText extends StatelessWidget {
  const _StepText({required this.number, required this.text});

  final int number;
  final String text;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 8),
      child: Row(
        children: <Widget>[
          CircleAvatar(radius: 13, backgroundColor: const Color(0xFFE4B663), child: Text('$number', style: const TextStyle(color: Color(0xFF2A1808), fontWeight: FontWeight.w900, fontSize: 12))),
          const SizedBox(width: 8),
          Expanded(child: Text(text, style: TextStyle(color: Colors.white.withOpacity(0.82), height: 1.45, fontSize: 12.5))),
        ],
      ),
    );
  }
}

class _MarketSheet extends StatelessWidget {
  const _MarketSheet({required this.resources, required this.onSell});

  final Map<String, int> resources;
  final VoidCallback onSell;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.fromLTRB(18, 16, 18, 18),
      decoration: const BoxDecoration(
        color: Color(0xFF211408),
        borderRadius: BorderRadius.vertical(top: Radius.circular(28)),
      ),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: <Widget>[
          const Text('بازار منطقه', style: TextStyle(color: Color(0xFFFFE1A1), fontSize: 22, fontWeight: FontWeight.w900)),
          const SizedBox(height: 8),
          Text('در این نسخه، بازار درآمد خودکار ندارد؛ فقط آیتم‌هایی را که جمع کرده‌ای می‌فروشی. قیمت‌ها در نسخه آنلاین از سرور می‌آیند.', style: TextStyle(color: Colors.white.withOpacity(0.78), height: 1.55)),
          const SizedBox(height: 12),
          Wrap(
            spacing: 8,
            runSpacing: 8,
            children: <Widget>[
              _ResourceTag(text: 'چوب: ${resources['wood'] ?? 0}'),
              _ResourceTag(text: 'سنگ: ${resources['stone'] ?? 0}'),
              _ResourceTag(text: 'آهن: ${resources['iron'] ?? 0}'),
              _ResourceTag(text: 'غذا: ${resources['food'] ?? 0}'),
            ],
          ),
          const SizedBox(height: 16),
          _PrimaryGameButton(label: 'فروش بسته کوچک منابع', icon: Icons.sell_rounded, onTap: () { onSell(); Navigator.of(context).pop(); }),
        ],
      ),
    );
  }
}

class _BottomGameMenu extends StatelessWidget {
  const _BottomGameMenu({required this.onMarket});

  final VoidCallback onMarket;

  @override
  Widget build(BuildContext context) {
    return Container(
      height: 66,
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(22),
        color: const Color(0xDD20140A),
        border: Border.all(color: const Color(0xFFE4B663)),
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
        children: <Widget>[
          _BottomItem(icon: Icons.storefront_rounded, label: 'بازار', onTap: onMarket),
          _BottomItem(icon: Icons.inventory_rounded, label: 'انبار', onTap: () {}),
          _BottomItem(icon: Icons.construction_rounded, label: 'ساخت', onTap: () {}),
          _BottomItem(icon: Icons.map_rounded, label: 'نقشه', onTap: () {}),
          _BottomItem(icon: Icons.emoji_events_rounded, label: 'رتبه', onTap: () {}),
        ],
      ),
    );
  }
}

class _BottomItem extends StatelessWidget {
  const _BottomItem({required this.icon, required this.label, required this.onTap});

  final IconData icon;
  final String label;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return InkWell(
      borderRadius: BorderRadius.circular(14),
      onTap: onTap,
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 4),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: <Widget>[
            Icon(icon, color: const Color(0xFFFFD17A), size: 23),
            const SizedBox(height: 2),
            Text(label, style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w800, fontSize: 11)),
          ],
        ),
      ),
    );
  }
}

class _PrimaryGameButton extends StatelessWidget {
  const _PrimaryGameButton({required this.label, required this.icon, this.onTap});

  final String label;
  final IconData icon;
  final VoidCallback? onTap;

  @override
  Widget build(BuildContext context) {
    final enabled = onTap != null;
    return InkWell(
      borderRadius: BorderRadius.circular(18),
      onTap: onTap,
      child: Opacity(
        opacity: enabled ? 1 : 0.55,
        child: Container(
          height: 48,
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(18),
            gradient: const LinearGradient(colors: <Color>[Color(0xFFFFCA66), Color(0xFFC98225)]),
            border: Border.all(color: const Color(0xFFFFE0A1), width: 1.4),
            boxShadow: <BoxShadow>[BoxShadow(color: Colors.black.withOpacity(0.34), blurRadius: 12, offset: const Offset(0, 6))],
          ),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: <Widget>[
              Icon(icon, color: const Color(0xFF311C09)),
              const SizedBox(width: 8),
              Text(label, style: const TextStyle(color: Color(0xFF311C09), fontWeight: FontWeight.w900, fontSize: 15)),
            ],
          ),
        ),
      ),
    );
  }
}

class _MenuButton extends StatelessWidget {
  const _MenuButton({required this.label, required this.icon, required this.onTap});

  final String label;
  final IconData icon;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return InkWell(
      borderRadius: BorderRadius.circular(16),
      onTap: onTap,
      child: Container(
        height: 46,
        padding: const EdgeInsets.symmetric(horizontal: 12),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(16),
          color: Colors.black.withOpacity(0.22),
          border: Border.all(color: const Color(0x88E4B663)),
        ),
        child: Row(
          children: <Widget>[
            Icon(icon, color: const Color(0xFFFFD17A), size: 21),
            const SizedBox(width: 8),
            Expanded(child: Text(label, style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w800))),
          ],
        ),
      ),
    );
  }
}

class _RoundIconButton extends StatelessWidget {
  const _RoundIconButton({required this.icon, required this.tooltip, required this.onTap});

  final IconData icon;
  final String tooltip;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return Tooltip(
      message: tooltip,
      child: InkWell(
        borderRadius: BorderRadius.circular(30),
        onTap: onTap,
        child: Container(
          width: 52,
          height: 52,
          decoration: BoxDecoration(
            shape: BoxShape.circle,
            gradient: const LinearGradient(colors: <Color>[Color(0xFFE2B761), Color(0xFF8C5B1E)]),
            border: Border.all(color: const Color(0xFFFFE0A1), width: 2),
            boxShadow: <BoxShadow>[BoxShadow(color: Colors.black.withOpacity(0.36), blurRadius: 12, offset: const Offset(0, 6))],
          ),
          child: Icon(icon, color: const Color(0xFF251407), size: 27),
        ),
      ),
    );
  }
}

class _TitleChip extends StatelessWidget {
  const _TitleChip({required this.title, required this.subtitle});

  final String title;
  final String subtitle;

  @override
  Widget build(BuildContext context) {
    return Container(
      width: 420,
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(22),
        color: const Color(0xCC20140A),
        border: Border.all(color: const Color(0xCCE4B663)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          Text(title, style: const TextStyle(color: Color(0xFFFFE1A1), fontWeight: FontWeight.w900, fontSize: 17)),
          const SizedBox(height: 3),
          Text(subtitle, style: TextStyle(color: Colors.white.withOpacity(0.72), fontSize: 11.5)),
        ],
      ),
    );
  }
}

class _ResourceTag extends StatelessWidget {
  const _ResourceTag({required this.text});

  final String text;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 9, vertical: 5),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(14),
        color: Colors.black.withOpacity(0.24),
        border: Border.all(color: const Color(0x66FFFFFF)),
      ),
      child: Text(text, style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w800, fontSize: 11.5)),
    );
  }
}

class SplashPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final sky = Paint()
      ..shader = const LinearGradient(colors: <Color>[Color(0xFF28485B), Color(0xFFE0A557)], begin: Alignment.topCenter, end: Alignment.bottomCenter).createShader(Offset.zero & size);
    canvas.drawRect(Offset.zero & size, sky);

    final sun = Paint()..color = const Color(0xFFFFD479).withOpacity(0.85);
    canvas.drawCircle(Offset(size.width * 0.2, size.height * 0.22), size.height * 0.12, sun);

    final mountain = Paint()..color = const Color(0xFF3A2A1B).withOpacity(0.65);
    final path = Path()
      ..moveTo(0, size.height * 0.58)
      ..lineTo(size.width * 0.18, size.height * 0.32)
      ..lineTo(size.width * 0.38, size.height * 0.58)
      ..lineTo(size.width * 0.56, size.height * 0.35)
      ..lineTo(size.width * 0.82, size.height * 0.58)
      ..lineTo(size.width, size.height * 0.42)
      ..lineTo(size.width, size.height)
      ..lineTo(0, size.height)
      ..close();
    canvas.drawPath(path, mountain);

    final ground = Paint()
      ..shader = const LinearGradient(colors: <Color>[Color(0xFF79512A), Color(0xFF2B1808)], begin: Alignment.topCenter, end: Alignment.bottomCenter).createShader(Rect.fromLTWH(0, size.height * 0.52, size.width, size.height * 0.48));
    canvas.drawRect(Rect.fromLTWH(0, size.height * 0.52, size.width, size.height * 0.48), ground);

    _drawBazaar(canvas, size);
    _drawRoad(canvas, size);
  }

  void _drawBazaar(Canvas canvas, Size size) {
    final rng = math.Random(7);
    for (int i = 0; i < 36; i++) {
      final x = size.width * (0.05 + rng.nextDouble() * 0.86);
      final y = size.height * (0.46 + rng.nextDouble() * 0.23);
      final w = size.width * (0.035 + rng.nextDouble() * 0.025);
      final h = size.height * (0.055 + rng.nextDouble() * 0.06);
      final wall = Paint()..color = Color.lerp(const Color(0xFFB87B42), const Color(0xFFE2B76A), rng.nextDouble())!.withOpacity(0.95);
      canvas.drawRRect(RRect.fromRectAndRadius(Rect.fromLTWH(x, y, w, h), const Radius.circular(5)), wall);
      final roof = Paint()..color = const Color(0xFF5C2E1D).withOpacity(0.9);
      final roofPath = Path()..moveTo(x - 4, y + 4)..lineTo(x + w / 2, y - h * 0.34)..lineTo(x + w + 4, y + 4)..close();
      canvas.drawPath(roofPath, roof);
      if (i % 6 == 0) {
        final dome = Paint()..color = const Color(0xFF34A6A7).withOpacity(0.9);
        canvas.drawOval(Rect.fromLTWH(x + w * 0.18, y - h * 0.38, w * 0.64, h * 0.45), dome);
      }
    }
  }

  void _drawRoad(Canvas canvas, Size size) {
    final road = Path()
      ..moveTo(size.width * 0.38, size.height)
      ..quadraticBezierTo(size.width * 0.46, size.height * 0.72, size.width * 0.50, size.height * 0.55)
      ..quadraticBezierTo(size.width * 0.54, size.height * 0.72, size.width * 0.66, size.height)
      ..close();
    canvas.drawPath(road, Paint()..color = const Color(0xFFC39355).withOpacity(0.72));
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}

class ParchmentBackgroundPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final bg = Paint()
      ..shader = const LinearGradient(colors: <Color>[Color(0xFF5B3A18), Color(0xFFB88945), Color(0xFF3A210C)], begin: Alignment.topLeft, end: Alignment.bottomRight).createShader(Offset.zero & size);
    canvas.drawRect(Offset.zero & size, bg);
    final vignette = Paint()
      ..shader = RadialGradient(colors: <Color>[Colors.transparent, Colors.black.withOpacity(0.45)], radius: 0.86).createShader(Offset.zero & size);
    canvas.drawRect(Offset.zero & size, vignette);
    final gridPaint = Paint()..color = Colors.white.withOpacity(0.035)..strokeWidth = 1;
    for (double x = 0; x < size.width; x += 44) {
      canvas.drawLine(Offset(x, 0), Offset(x + 120, size.height), gridPaint);
    }
    for (double y = 0; y < size.height; y += 44) {
      canvas.drawLine(Offset(0, y), Offset(size.width, y + 80), gridPaint);
    }
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}

class IranMapPainter extends CustomPainter {
  IranMapPainter({required this.selected});

  final RegionData? selected;

  @override
  void paint(Canvas canvas, Size size) {
    final rect = Offset.zero & size;
    final parchment = Paint()
      ..shader = const LinearGradient(colors: <Color>[Color(0xFFE9C487), Color(0xFFBD8745), Color(0xFF6E431E)], begin: Alignment.topLeft, end: Alignment.bottomRight).createShader(rect);
    canvas.drawRect(rect, parchment);

    final mapRect = Rect.fromLTWH(size.width * 0.12, size.height * 0.09, size.width * 0.76, size.height * 0.78);
    final path = Path()
      ..moveTo(mapRect.left + mapRect.width * 0.18, mapRect.top + mapRect.height * 0.28)
      ..quadraticBezierTo(mapRect.left + mapRect.width * 0.28, mapRect.top + mapRect.height * 0.08, mapRect.left + mapRect.width * 0.48, mapRect.top + mapRect.height * 0.12)
      ..quadraticBezierTo(mapRect.left + mapRect.width * 0.72, mapRect.top + mapRect.height * 0.08, mapRect.left + mapRect.width * 0.86, mapRect.top + mapRect.height * 0.30)
      ..quadraticBezierTo(mapRect.left + mapRect.width * 0.95, mapRect.top + mapRect.height * 0.48, mapRect.left + mapRect.width * 0.82, mapRect.top + mapRect.height * 0.62)
      ..quadraticBezierTo(mapRect.left + mapRect.width * 0.68, mapRect.top + mapRect.height * 0.82, mapRect.left + mapRect.width * 0.48, mapRect.top + mapRect.height * 0.86)
      ..quadraticBezierTo(mapRect.left + mapRect.width * 0.30, mapRect.top + mapRect.height * 0.88, mapRect.left + mapRect.width * 0.15, mapRect.top + mapRect.height * 0.67)
      ..quadraticBezierTo(mapRect.left + mapRect.width * 0.03, mapRect.top + mapRect.height * 0.48, mapRect.left + mapRect.width * 0.18, mapRect.top + mapRect.height * 0.28)
      ..close();

    canvas.save();
    canvas.clipPath(path);
    _paintRegion(canvas, size, Rect.fromLTWH(mapRect.left, mapRect.top, mapRect.width, mapRect.height * 0.5), regionById(RegionId.north));
    _paintRegion(canvas, size, Rect.fromLTWH(mapRect.left, mapRect.center.dy, mapRect.width, mapRect.height * 0.5), regionById(RegionId.south));
    _paintRegion(canvas, size, Rect.fromLTWH(mapRect.left, mapRect.top, mapRect.width * 0.5, mapRect.height), regionById(RegionId.west));
    _paintRegion(canvas, size, Rect.fromLTWH(mapRect.center.dx, mapRect.top, mapRect.width * 0.5, mapRect.height), regionById(RegionId.east));
    canvas.restore();

    final stroke = Paint()..style = PaintingStyle.stroke..strokeWidth = 4..color = const Color(0xFFFFE0A1);
    canvas.drawPath(path, stroke);
    final shadowStroke = Paint()..style = PaintingStyle.stroke..strokeWidth = 10..color = Colors.black.withOpacity(0.16);
    canvas.drawPath(path, shadowStroke);

    final divider = Paint()..color = const Color(0xFFFFE0A1).withOpacity(0.64)..strokeWidth = 3;
    canvas.drawLine(Offset(mapRect.center.dx, mapRect.top + 12), Offset(mapRect.center.dx, mapRect.bottom - 12), divider);
    canvas.drawLine(Offset(mapRect.left + 24, mapRect.center.dy), Offset(mapRect.right - 24, mapRect.center.dy), divider);

    if (selected != null) {
      final highlight = Paint()..color = selected!.color.withOpacity(0.28)..style = PaintingStyle.fill;
      canvas.drawPath(path, highlight);
    }

    _drawCompass(canvas, size);
    _drawTinyCaravan(canvas, size, mapRect);
  }

  void _paintRegion(Canvas canvas, Size size, Rect rect, RegionData data) {
    final isSelected = selected?.id == data.id;
    final paint = Paint()
      ..shader = LinearGradient(colors: <Color>[data.color.withOpacity(isSelected ? 0.78 : 0.40), data.secondaryColor.withOpacity(isSelected ? 0.72 : 0.33)], begin: Alignment.topCenter, end: Alignment.bottomCenter).createShader(rect);
    canvas.drawRect(rect, paint);
  }

  void _drawCompass(Canvas canvas, Size size) {
    final center = Offset(size.width * 0.11, size.height * 0.84);
    final p = Paint()..color = const Color(0xFFFFE0A1).withOpacity(0.45)..style = PaintingStyle.stroke..strokeWidth = 2;
    canvas.drawCircle(center, 38, p);
    canvas.drawLine(center + const Offset(0, -46), center + const Offset(0, 46), p);
    canvas.drawLine(center + const Offset(-46, 0), center + const Offset(46, 0), p);
  }

  void _drawTinyCaravan(Canvas canvas, Size size, Rect mapRect) {
    final p = Paint()..color = const Color(0xFF3A210C).withOpacity(0.55);
    for (int i = 0; i < 5; i++) {
      final x = mapRect.left + mapRect.width * (0.22 + i * 0.075);
      final y = mapRect.top + mapRect.height * (0.70 + math.sin(i) * 0.03);
      canvas.drawOval(Rect.fromCenter(center: Offset(x, y), width: 20, height: 10), p);
      canvas.drawCircle(Offset(x + 9, y - 6), 4, p);
    }
  }

  @override
  bool shouldRepaint(covariant IranMapPainter oldDelegate) => oldDelegate.selected != selected;
}

class GuideCharacterPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final center = Offset(size.width / 2, size.height * 0.48);
    final cloak = Paint()..color = const Color(0xFF8B5A2B);
    final outline = Paint()..color = const Color(0xFF241408)..style = PaintingStyle.stroke..strokeWidth = 3;
    canvas.drawCircle(Offset(center.dx, center.dy - 58), 32, Paint()..color = const Color(0xFFD9A66A));
    canvas.drawPath(
      Path()
        ..moveTo(center.dx - 60, center.dy + 90)
        ..quadraticBezierTo(center.dx, center.dy - 24, center.dx + 60, center.dy + 90)
        ..close(),
      cloak,
    );
    canvas.drawPath(
      Path()
        ..moveTo(center.dx - 60, center.dy + 90)
        ..quadraticBezierTo(center.dx, center.dy - 24, center.dx + 60, center.dy + 90)
        ..close(),
      outline,
    );
    final turban = Paint()..color = const Color(0xFFFFE1A1);
    canvas.drawOval(Rect.fromCenter(center: Offset(center.dx, center.dy - 88), width: 78, height: 32), turban);
    canvas.drawRRect(RRect.fromRectAndRadius(Rect.fromCenter(center: Offset(center.dx, center.dy - 46), width: 70, height: 26), const Radius.circular(16)), turban);
    final staff = Paint()..color = const Color(0xFFCF9F51)..strokeWidth = 6..strokeCap = StrokeCap.round;
    canvas.drawLine(Offset(center.dx + 58, center.dy - 20), Offset(center.dx + 76, center.dy + 95), staff);
    canvas.drawCircle(Offset(center.dx + 58, center.dy - 20), 9, Paint()..color = const Color(0xFFFFD17A));
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}

class CloudPainter extends CustomPainter {
  CloudPainter({required this.alignment});

  final Alignment alignment;

  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()..color = Colors.white.withOpacity(0.72);
    final baseX = alignment.x < 0 ? size.width * 0.2 : size.width * 0.8;
    final rng = math.Random(alignment.x < 0 ? 11 : 13);
    for (int i = 0; i < 28; i++) {
      final x = baseX + (rng.nextDouble() - 0.5) * size.width * 0.38;
      final y = size.height * (0.08 + rng.nextDouble() * 0.86);
      final r = size.height * (0.05 + rng.nextDouble() * 0.09);
      canvas.drawCircle(Offset(x, y), r, paint);
    }
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}

class RegionLandPainter extends CustomPainter {
  RegionLandPainter({required this.region});

  final RegionData region;

  @override
  void paint(Canvas canvas, Size size) {
    _drawBase(canvas, size);
    _drawIsometricGround(canvas, size);
    _drawVillage(canvas, size);
  }

  void _drawBase(Canvas canvas, Size size) {
    final bgColors = switch (region.id) {
      RegionId.north => const <Color>[Color(0xFF4B7449), Color(0xFF9B7A3C), Color(0xFF2E2614)],
      RegionId.south => const <Color>[Color(0xFFB77B37), Color(0xFF8D5E2E), Color(0xFF2C1708)],
      RegionId.west => const <Color>[Color(0xFF5F6B3B), Color(0xFF8A6C43), Color(0xFF24170B)],
      RegionId.east => const <Color>[Color(0xFF9A7A3B), Color(0xFF7A4C62), Color(0xFF26120C)],
    };
    final bg = Paint()..shader = LinearGradient(colors: bgColors, begin: Alignment.topCenter, end: Alignment.bottomCenter).createShader(Offset.zero & size);
    canvas.drawRect(Offset.zero & size, bg);
    final sun = Paint()..color = const Color(0xFFFFD17A).withOpacity(0.6);
    canvas.drawCircle(Offset(size.width * 0.14, size.height * 0.18), size.height * 0.08, sun);
  }

  void _drawIsometricGround(Canvas canvas, Size size) {
    final tile = Paint()..color = Colors.black.withOpacity(0.08)..strokeWidth = 1;
    for (double i = -size.width; i < size.width * 2; i += 58) {
      canvas.drawLine(Offset(i, size.height * 0.2), Offset(i + size.height, size.height), tile);
      canvas.drawLine(Offset(i, size.height), Offset(i + size.height, size.height * 0.2), tile);
    }
    final path = Path()
      ..moveTo(size.width * 0.08, size.height * 0.72)
      ..lineTo(size.width * 0.50, size.height * 0.34)
      ..lineTo(size.width * 0.92, size.height * 0.72)
      ..lineTo(size.width * 0.50, size.height * 1.02)
      ..close();
    canvas.drawPath(path, Paint()..color = const Color(0xFFD0A25B).withOpacity(0.28));
    canvas.drawPath(path, Paint()..color = const Color(0xFFFFE1A1).withOpacity(0.20)..style = PaintingStyle.stroke..strokeWidth = 3);
  }

  void _drawVillage(Canvas canvas, Size size) {
    final rng = math.Random(region.id.index + 2);
    for (int i = 0; i < 18; i++) {
      final x = size.width * (0.18 + rng.nextDouble() * 0.55);
      final y = size.height * (0.32 + rng.nextDouble() * 0.34);
      final w = size.width * (0.035 + rng.nextDouble() * 0.03);
      final h = size.height * (0.045 + rng.nextDouble() * 0.05);
      _drawHouse(canvas, Offset(x, y), Size(w, h), i % 4 == 0);
    }
    _drawResourceArea(canvas, size);
  }

  void _drawHouse(Canvas canvas, Offset topLeft, Size s, bool dome) {
    final wall = Paint()..color = const Color(0xFFC79457);
    final roof = Paint()..color = const Color(0xFF5C331B);
    canvas.drawRRect(RRect.fromRectAndRadius(topLeft & s, const Radius.circular(5)), wall);
    final p = Path()..moveTo(topLeft.dx - 4, topLeft.dy + 4)..lineTo(topLeft.dx + s.width / 2, topLeft.dy - s.height * 0.35)..lineTo(topLeft.dx + s.width + 4, topLeft.dy + 4)..close();
    canvas.drawPath(p, roof);
    if (dome) {
      canvas.drawOval(Rect.fromLTWH(topLeft.dx + s.width * 0.18, topLeft.dy - s.height * 0.46, s.width * 0.64, s.height * 0.48), Paint()..color = region.color.withOpacity(0.9));
    }
  }

  void _drawResourceArea(Canvas canvas, Size size) {
    final paint = Paint()..color = region.color.withOpacity(0.72);
    if (region.id == RegionId.north) {
      for (int i = 0; i < 16; i++) {
        final x = size.width * (0.05 + i * 0.035);
        final y = size.height * (0.28 + math.sin(i) * 0.04);
        canvas.drawRect(Rect.fromLTWH(x, y, 8, 38), Paint()..color = const Color(0xFF5B351C));
        canvas.drawCircle(Offset(x + 4, y - 5), 24, paint);
      }
    } else if (region.id == RegionId.south) {
      for (int i = 0; i < 12; i++) {
        final x = size.width * (0.1 + i * 0.045);
        final y = size.height * (0.18 + math.sin(i) * 0.04);
        canvas.drawPath(Path()..moveTo(x, y + 50)..lineTo(x + 22, y)..lineTo(x + 46, y + 50)..close(), Paint()..color = const Color(0xFF726254));
      }
    } else if (region.id == RegionId.west) {
      for (int i = 0; i < 11; i++) {
        final x = size.width * (0.08 + i * 0.055);
        final y = size.height * (0.18 + math.sin(i * 1.4) * 0.04);
        canvas.drawOval(Rect.fromCenter(center: Offset(x, y), width: 38, height: 18), Paint()..color = const Color(0xFFE8D2AC));
      }
    } else {
      for (int i = 0; i < 13; i++) {
        final x = size.width * (0.08 + i * 0.046);
        final y = size.height * (0.22 + math.sin(i) * 0.03);
        canvas.drawCircle(Offset(x, y), 10, Paint()..color = const Color(0xFFB34D75));
        canvas.drawLine(Offset(x, y + 10), Offset(x, y + 38), Paint()..color = const Color(0xFF5A3B22)..strokeWidth = 3);
      }
    }
  }

  @override
  bool shouldRepaint(covariant RegionLandPainter oldDelegate) => oldDelegate.region != region;
}
